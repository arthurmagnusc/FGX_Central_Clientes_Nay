/** Identidade FGX. Os tokens vivem aqui e em src/estilos.css — nunca soltos nos componentes. */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        fgx: {
          red: "#B12119", orange: "#E77938", "red-dark": "#7E131C",
          beige: "#D9BCAA", "beige-light": "#FAE7CF",
          green: "#527F3E", gold: "#FAB826", blue: "#356FA9",
        },
        ink: { DEFAULT: "#1C1A19", 2: "#4A4341", 3: "#7A716D" },
        linha: "#E7E1DD",
        fundo: "#F6F3F1",
      },
      fontFamily: {
        titulo: ["'Titillium Web'", "system-ui", "sans-serif"],
        corpo: ["Montserrat", "system-ui", "sans-serif"],
      },
      boxShadow: {
        cartao: "0 1px 2px rgba(28,26,25,.03), 0 3px 14px rgba(28,26,25,.05)",
        alto: "0 4px 30px rgba(28,26,25,.10)",
      },
    },
  },
  plugins: [],
};
