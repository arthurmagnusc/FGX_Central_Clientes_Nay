# Portal do Cliente FGX

Portal onde os clientes de recorrência da FGX Gestão acessam os entregáveis do
contrato, leem os relatórios do período e validam o conteúdo técnico produzido
para eles — comentando trecho a trecho.

Dois lados na mesma aplicação:

- **`/c/:slug`** — portal do cliente (barra lateral vinho)
- **`/admin`** — painel interno da equipe FGX (barra lateral preta)

A diferença de cor é proposital: quem opera os dois lados precisa saber num
relance onde está antes de clicar em publicar.

---

## Stack

| Camada | Escolha |
|---|---|
| Front | React 18 + TypeScript + Vite + Tailwind + React Router |
| Banco | Supabase (Postgres) com **RLS** garantindo o isolamento entre clientes |
| Arquivos | Supabase Storage, bucket privado, download por URL assinada |
| Servidor | Supabase Edge Functions (Deno) para login, download e webhook |
| Testes | Vitest (unitário), Playwright (ponta a ponta), psql (políticas de RLS) |

---

## Subir o projeto

```bash
npm install
cp .env.example .env          # preencha com os dados do seu projeto Supabase
```

### 1. Banco

```bash
supabase link --project-ref SEU_REF
supabase db push              # aplica supabase/migrations/*
psql "$DATABASE_URL" -f supabase/seed.sql
```

O seed cria os três escritórios **sem senha e inativos**, os canais e as
editorias e pilares da Fiedra. Nenhuma senha vive em migration ou seed.

### 2. Administrador e senhas

```bash
ADMIN_SENHA_INICIAL='troque-esta-senha-agora' npm run criar-admin
node scripts/definir-senha-cliente.mjs fiedra 'senha-do-escritorio'
```

Enquanto um cliente não tiver senha, `/c/<slug>` responde que o acesso não foi
liberado. Enquanto a senha inicial do admin não for trocada, o painel exibe um
aviso permanente em todas as telas.

### 3. Edge Functions

```bash
supabase secrets set --env-file .env.functions
supabase functions deploy entrar entrar-admin baixar-entregavel baixar-relatorio enviar-ajuste
```

### 4. Front

```bash
npm run dev      # http://localhost:5173
npm run build    # publica a pasta dist/ onde preferir
```

---

## Testes

```bash
npm run teste        # unitários: divisão em blocos e sanitização
npm run teste:e2e    # ponta a ponta: fidelidade e persistência
```

O teste de isolamento roda contra um Supabase real:

```bash
SUPABASE_URL=... SUPABASE_ANON_KEY=... SUPABASE_SERVICE_ROLE_KEY=... \
SUPABASE_JWT_SECRET=... npm run teste
```

Para o teste de fidelidade, semeie o cenário primeiro:

```bash
node testes/apoio/semear.mjs        # imprime PECA_TESTE e TEXTO_TESTE
```

As políticas de RLS têm um teste próprio, em SQL puro — veja
`supabase/README-testes-rls.md`. **Rode-o sempre que mexer numa policy.** Ele já
pegou dois bugs que não apareciam na leitura do código.

---

## Tarefas do dia a dia

**Cadastrar uma peça.** `/admin/ciclos` → *Nova peça* → cole o texto da produção
e clique em *Dividir em blocos*. O botão quebra por parágrafo, por título
markdown ou por separador `---`. Depois dá para juntar, separar, reordenar e
editar bloco a bloco. Cada bloco é o que o cliente vai poder comentar
isoladamente.

**Publicar o ciclo.** Enquanto o ciclo está em rascunho, o cliente não vê nada —
isso é garantido pelo banco, não pela interface.

**Tratar comentários.** `/admin/comentarios` reúne tudo o que o cliente escreveu.
Cada comentário vira ajuste *pontual* (muda só aquela peça) ou *estrutural* (muda
a regra-base do cliente e gera um documento aditivo em `.md`), ou é marcado como
tratado sem ajuste.

**Encaminhar para avaliação.** Em `/admin/ajustes`, o botão monta um JSON com
cliente, tom de voz, peça inteira, comentário de origem e o ajuste, e faz POST no
`WEBHOOK_AVALIACAO_AJUSTE`. Sem a variável, baixa o mesmo JSON — o botão nunca
fica morto.

---

## Regra crítica: fidelidade do conteúdo

O conteúdo da peça aparece **exatamente como foi cadastrado**. Sem resumir,
truncar, cortar com reticências, esconder atrás de "ver mais" ou limitar altura
com rolagem interna.

Isso não é preferência de estilo — é a condição de aceite do projeto, porque um
protótipo anterior resumia o conteúdo e o cliente perdia a confiança na
validação. Há três defesas no código:

1. `peca_bloco.conteudo` é `TEXT`, sem limite.
2. `src/lib/sanitizar.ts` remove apenas script e handlers; a lista de tags
   permitidas cobre todo o texto formatado do escritório.
3. `testes/fidelidade.spec.ts` cadastra 8.000 caracteres, lê pela interface e
   compara caractere a caractere — e falha se encontrar qualquer sintoma de
   corte, inclusive `max-height` com `overflow`.

O limite de caracteres do canal serve só para **mostrar** ao cliente quanto a
peça tem versus o limite. Ele nunca corta, esconde nem bloqueia texto.

---

## Onde estão as decisões

`HANDOFF.md` explica por que cada escolha foi feita, o que ficou de fora e quais
são os pontos que merecem atenção antes de colocar cliente real.
