/**
 * TESTE OBRIGATÓRIO 2 — isolamento entre clientes.
 *
 * Roda contra um Supabase real (local, via `supabase start`, ou de staging).
 * Pula sozinho se as variáveis não estiverem definidas, para não quebrar CI
 * de quem só quer rodar os testes unitários.
 *
 *   SUPABASE_URL=... SUPABASE_ANON_KEY=... SUPABASE_JWT_SECRET=... npm run teste
 *
 * O que ele prova: com o token do cliente A, NENHUMA leitura devolve linha do
 * cliente B — nem alterando a consulta, nem pedindo a linha pelo id exato.
 */
import { createClient } from "@supabase/supabase-js";
import { beforeAll, describe, expect, it } from "vitest";
import { SignJWT } from "jose";

const URL = process.env.SUPABASE_URL;
const ANON = process.env.SUPABASE_ANON_KEY;
const SERVICE = process.env.SUPABASE_SERVICE_ROLE_KEY;
const SEGREDO = process.env.SUPABASE_JWT_SECRET;

const rodar = URL && ANON && SERVICE && SEGREDO ? describe : describe.skip;

async function tokenDe(claims: Record<string, unknown>) {
  return new SignJWT({ role: "authenticated", ...claims })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("1h")
    .sign(new TextEncoder().encode(SEGREDO!));
}

rodar("isolamento entre clientes", () => {
  let idA = "", idB = "", pecaB = "", entregavelB = "";
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let comoA: any;

  beforeAll(async () => {
    const admin: any = createClient(URL!, SERVICE!, { auth: { persistSession: false } });

    const { data: clientes } = await admin.from("cliente").select("id, slug").in("slug", ["fiedra", "rsta"]);
    idA = clientes!.find((c: any) => c.slug === "fiedra")!.id;
    idB = clientes!.find((c: any) => c.slug === "rsta")!.id;

    // Dado do cliente B, publicado — o cenário mais permissivo possível.
    const { data: ciclo } = await admin.from("ciclo").insert({
      cliente_id: idB, mes_referencia: "2099-01", status: "publicado", publicado_em: new Date().toISOString(),
    }).select("id").single();

    const { data: p } = await admin.from("peca").insert({
      ciclo_id: ciclo!.id, tema: "Segredo do cliente B", canal_codigo: "blog", formato: "artigo",
    }).select("id").single();
    pecaB = p!.id;
    await admin.from("peca_bloco").insert({ peca_id: pecaB, ordem: 1, conteudo: "conteúdo confidencial de B" });

    const { data: e } = await admin.from("entregavel").insert({
      cliente_id: idB, categoria: "diagnostico", titulo: "Diagnóstico de B",
      storage_path: "b/diag.pdf", nome_arquivo: "diag.pdf", publicado_em: new Date().toISOString(),
    }).select("id").single();
    entregavelB = e!.id;

    const token = await tokenDe({ sub: crypto.randomUUID(), cliente_id: idA, pessoa_nome: "Teste A", is_admin: false });
    comoA = createClient(URL!, ANON!, {
      auth: { persistSession: false },
      global: { headers: { Authorization: `Bearer ${token}` } },
    });
  });

  it("A não lista peças de B", async () => {
    const { data } = await comoA.from("peca").select("id, tema");
    expect((data ?? []).some((p: any) => p.id === pecaB)).toBe(false);
  });

  it("A não lê a peça de B nem pedindo pelo id exato", async () => {
    const { data } = await comoA.from("peca").select("*").eq("id", pecaB);
    expect(data).toEqual([]);
  });

  it("A não lê blocos de B — é onde o conteúdo mora", async () => {
    const { data } = await comoA.from("peca_bloco").select("*").eq("peca_id", pecaB);
    expect(data).toEqual([]);
  });

  it("A não lê entregáveis de B", async () => {
    const { data } = await comoA.from("entregavel").select("*").eq("id", entregavelB);
    expect(data).toEqual([]);
  });

  it("A não lê o cadastro de B", async () => {
    const { data } = await comoA.from("cliente").select("*").eq("id", idB);
    expect(data).toEqual([]);
  });

  it("A não consegue comentar em peça de B", async () => {
    const { error } = await comoA.from("comentario").insert({
      peca_id: pecaB, autor_nome: "Teste A", autor_tipo: "cliente", texto: "invasão",
    });
    expect(error).toBeTruthy();
  });

  it("A não consegue comentar assinando com outro nome", async () => {
    const { data: minhas } = await comoA.from("peca").select("id").limit(1);
    if (!minhas?.length) return;
    const { error } = await comoA.from("comentario").insert({
      peca_id: minhas[0].id, autor_nome: "Outra Pessoa", autor_tipo: "cliente", texto: "falsificado",
    });
    expect(error).toBeTruthy();
  });

  it("A não consegue editar o conteúdo da própria peça", async () => {
    const { data: minhas } = await comoA.from("peca").select("id").limit(1);
    if (!minhas?.length) return;
    const { data: blocos } = await comoA.from("peca_bloco").select("id").eq("peca_id", minhas[0].id).limit(1);
    if (!blocos?.length) return;
    const { error } = await comoA.from("peca_bloco").update({ conteudo: "reescrito pelo cliente" }).eq("id", blocos[0].id);
    // Sem policy de update para cliente: a linha não é afetada ou o insert falha.
    const { data: conferir } = await comoA.from("peca_bloco").select("conteudo").eq("id", blocos[0].id).single();
    expect(conferir?.conteudo).not.toBe("reescrito pelo cliente");
    expect(error === null || !!error).toBe(true);
  });
});
