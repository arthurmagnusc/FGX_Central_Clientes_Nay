import { expect, test } from "@playwright/test";

/**
 * TESTE OBRIGATÓRIO 1 — fidelidade do conteúdo.
 *
 * O protótipo anterior resumia o conteúdo em vez de reproduzi-lo. Este teste
 * existe para que isso não volte: cadastra um texto longo, lê pela interface
 * do cliente e compara caractere a caractere.
 *
 * Precisa de: SLUG_TESTE, SENHA_TESTE e um ciclo publicado com a peça semeada
 * por testes/apoio/semear.mjs.
 */
const SLUG = process.env.SLUG_TESTE ?? "fiedra";
const SENHA = process.env.SENHA_TESTE ?? "";
const PECA = process.env.PECA_TESTE ?? "";

test.skip(!SENHA || !PECA, "defina SENHA_TESTE e PECA_TESTE (veja testes/apoio/semear.mjs)");

test("o conteúdo da peça aparece na íntegra, sem truncar", async ({ page }) => {
  const esperado = process.env.TEXTO_TESTE!;
  expect(esperado.length).toBeGreaterThanOrEqual(8000);

  await page.goto(`/c/${SLUG}`);
  await page.fill("#senha", SENHA);
  await page.fill("#nome", "Teste Automatizado");
  await page.click('button[type="submit"]');
  await page.waitForURL(`**/c/${SLUG}/visao-geral`);

  await page.goto(`/c/${SLUG}/conteudos/${PECA}`);
  await page.waitForSelector(".corpo-bloco");

  const lido = (await page.locator(".corpo-bloco").allInnerTexts()).join("\n\n");

  // Comparação por caractere, ignorando só diferenças de espaço em branco que
  // o HTML naturalmente introduz.
  const normaliza = (s: string) => s.replace(/ /g, " ").replace(/\s+/g, " ").trim();
  expect(normaliza(lido)).toBe(normaliza(esperado));

  // Nenhum dos sintomas de corte pode existir na página.
  const html = await page.content();
  expect(html).not.toMatch(/ver mais|leia mais|\.\.\.\s*<\/|…\s*<\//i);

  const alturaLimitada = await page.evaluate(() =>
    Array.from(document.querySelectorAll(".corpo-bloco")).some((el) => {
      const e = getComputedStyle(el as Element);
      return (e.maxHeight !== "none" && e.overflowY !== "visible")
        || e.webkitLineClamp !== "none"
        || (el as HTMLElement).scrollHeight > (el as HTMLElement).clientHeight + 2;
    }));
  expect(alturaLimitada, "algum bloco está com altura limitada e rolagem interna").toBe(false);
});
