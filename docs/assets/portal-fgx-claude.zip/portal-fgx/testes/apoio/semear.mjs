#!/usr/bin/env node
/**
 * Semeia o cenário dos testes de fidelidade e persistência: um ciclo
 * publicado com uma peça de mais de 8.000 caracteres, contendo títulos,
 * listas, negrito, aspas, acentuação e caracteres especiais.
 *
 * Imprime as variáveis que os testes esperam.
 */
import { createClient } from "@supabase/supabase-js";

const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, SLUG_TESTE = "fiedra" } = process.env;
const db = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, { auth: { persistSession: false } });

const pedaco = (i) => `## Seção ${i}

Texto com **negrito**, *itálico*, “aspas tipográficas”, aspas 'simples', travessão —
e acentuação completa: ação, você, órgão, coração, três, países, ninguém.

- item de lista ${i}.1
- item de lista ${i}.2

Caracteres especiais: & < > " ' § ° º ª ≠ ½ €. Números: 1.234.567,89.
Parágrafo final da seção ${i}, com ponto e vírgula; dois pontos: e reticências…`;

const texto = Array.from({ length: 14 }, (_, i) => pedaco(i + 1)).join("\n\n");
if (texto.length < 8000) { console.error("Texto de teste ficou curto:", texto.length); process.exit(1); }

const { data: cliente } = await db.from("cliente").select("id").eq("slug", SLUG_TESTE).single();

await db.from("ciclo").delete().eq("cliente_id", cliente.id).eq("mes_referencia", "2098-01");
const { data: ciclo } = await db.from("ciclo").insert({
  cliente_id: cliente.id, mes_referencia: "2098-01", status: "publicado", publicado_em: new Date().toISOString(),
}).select("id").single();

const { data: peca } = await db.from("peca").insert({
  ciclo_id: ciclo.id, tema: "Peça de teste automatizado — fidelidade do conteúdo",
  canal_codigo: "blog", formato: "artigo", area_direito: "Teste", funil: "fundo",
}).select("id").single();

await db.from("peca_bloco").insert({ peca_id: peca.id, ordem: 1, conteudo: texto });

console.log("PECA_TESTE=" + peca.id);
console.log("TEXTO_TESTE<<'FIM'\n" + texto + "\nFIM");
console.log("\nExporte também SENHA_TESTE com a senha do cliente " + SLUG_TESTE + ".");
