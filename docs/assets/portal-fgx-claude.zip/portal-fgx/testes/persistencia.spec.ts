import { expect, test } from "@playwright/test";

/**
 * TESTE OBRIGATÓRIO 3 — persistência do comentário.
 * Grava, recarrega a página e confere que o comentário continua lá, com autor,
 * data e o trecho a que se refere.
 */
const SLUG = process.env.SLUG_TESTE ?? "fiedra";
const SENHA = process.env.SENHA_TESTE ?? "";
const PECA = process.env.PECA_TESTE ?? "";

test.skip(!SENHA || !PECA, "defina SENHA_TESTE e PECA_TESTE");

test("comentário em bloco sobrevive ao recarregamento", async ({ page }) => {
  const autor = "Teste Persistência";
  const texto = `Comentário de teste ${Date.now()} — com acentuação e “aspas”.`;

  await page.goto(`/c/${SLUG}`);
  await page.fill("#senha", SENHA);
  await page.fill("#nome", autor);
  await page.click('button[type="submit"]');
  await page.waitForURL(`**/visao-geral`);

  await page.goto(`/c/${SLUG}/conteudos/${PECA}`);
  const primeiroBloco = page.locator("[id^=bloco-]").first();
  await primeiroBloco.hover();
  await primeiroBloco.getByRole("button", { name: /Comentar neste/ }).click();
  await page.locator("textarea").first().fill(texto);
  await page.getByRole("button", { name: "Enviar comentário" }).click();

  await expect(page.getByText(texto)).toBeVisible();

  await page.reload();
  await page.waitForSelector(".corpo-bloco");

  // Continua no histórico lateral...
  await expect(page.getByText(texto).first()).toBeVisible();
  // ...com o autor da sessão...
  await expect(page.getByText(autor).first()).toBeVisible();
  // ...e ancorado ao bloco certo.
  await expect(primeiroBloco.getByText(texto)).toBeVisible();
});

test("se a gravação falhar, o texto não some do campo", async ({ page }) => {
  await page.goto(`/c/${SLUG}`);
  await page.fill("#senha", SENHA);
  await page.fill("#nome", "Teste Falha");
  await page.click('button[type="submit"]');
  await page.waitForURL("**/visao-geral");
  await page.goto(`/c/${SLUG}/conteudos/${PECA}`);

  // Derruba a escrita de comentário no meio do caminho.
  await page.route("**/rest/v1/comentario*", (rota) =>
    rota.fulfill({ status: 500, body: JSON.stringify({ message: "falha simulada" }) }));

  const rascunho = "Este texto não pode desaparecer.";
  const painel = page.locator("aside");
  await painel.locator("textarea").fill(rascunho);
  await painel.getByRole("button", { name: /Enviar como/ }).click();

  await expect(page.getByText(/Não deu para salvar/)).toBeVisible();
  await expect(painel.locator("textarea")).toHaveValue(rascunho);
});
