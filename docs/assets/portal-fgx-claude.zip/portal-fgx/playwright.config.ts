import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "./testes",
  testMatch: /.*\.spec\.ts/,
  use: { baseURL: process.env.URL_BASE ?? "http://localhost:5173" },
  webServer: process.env.URL_BASE ? undefined : {
    command: "npm run dev",
    url: "http://localhost:5173",
    reuseExistingServer: true,
  },
});
