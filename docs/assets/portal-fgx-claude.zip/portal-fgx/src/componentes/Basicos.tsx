import { useEffect, useState, type ReactNode } from "react";
import { NOME_STATUS, COR_STATUS } from "../lib/formato";
import type { StatusPeca } from "../lib/tipos";

export function Pilula({ status }: { status: StatusPeca }) {
  const fundo: Record<StatusPeca, string> = {
    pendente: "bg-[#F0EEEC] text-[#7A716D]",
    em_revisao: "bg-fgx-blue/10 text-[#2A5A8C]",
    ajustada: "bg-fgx-orange/[.13] text-[#B2531D]",
    aprovada: "bg-fgx-green/10 text-[#3F6530]",
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11.5px] font-semibold whitespace-nowrap ${fundo[status]}`}>
      {NOME_STATUS[status]}
    </span>
  );
}

export function BarraStatus({ contagem, total }: { contagem: Record<StatusPeca, number>; total: number }) {
  const ordem: StatusPeca[] = ["aprovada", "ajustada", "em_revisao", "pendente"];
  return (
    <>
      <div className="flex h-[9px] rounded-md overflow-hidden bg-fundo">
        {ordem.filter((s) => contagem[s]).map((s) => (
          <span key={s} style={{ width: `${(contagem[s] / total) * 100}%`, background: COR_STATUS[s] }} />
        ))}
      </div>
      <div className="flex flex-wrap gap-4 mt-3 text-[11.5px] text-ink-3">
        {ordem.map((s) => (
          <span key={s} className="flex items-center gap-1.5">
            <i className="w-2.5 h-2.5 rounded-[3px] inline-block" style={{ background: COR_STATUS[s] }} />
            {NOME_STATUS[s]} ({contagem[s]})
          </span>
        ))}
      </div>
    </>
  );
}

export function Recolhivel(
  { titulo, children, aberto = false }: { titulo: string; children: ReactNode; aberto?: boolean },
) {
  const [on, setOn] = useState(aberto);
  return (
    <section className="border-t border-linha">
      <button onClick={() => setOn(!on)}
        className="w-full flex items-center gap-2.5 px-7 py-4 font-titulo font-bold text-[15px] text-left hover:bg-[#FBFAF9]">
        {titulo}
        <span className={`ml-auto text-ink-3 text-xs transition ${on ? "rotate-180" : ""}`}>▾</span>
      </button>
      {on && <div className="px-7 pb-6">{children}</div>}
    </section>
  );
}

/** Avisos de topo. Some sozinho; erro fica até o usuário fechar. */
export function Aviso(
  { texto, tipo = "ok", aoFechar }: { texto: string; tipo?: "ok" | "erro"; aoFechar: () => void },
) {
  useEffect(() => {
    if (tipo === "erro") return;
    const t = setTimeout(aoFechar, 3000);
    return () => clearTimeout(t);
  }, [texto, tipo, aoFechar]);
  return (
    <div role="status" aria-live="polite"
      className={`fixed left-1/2 -translate-x-1/2 bottom-7 z-50 px-5 py-3 rounded-xl text-[13.5px] font-medium text-white shadow-alto max-w-[88vw] text-center
        ${tipo === "ok" ? "bg-[#3F6530]" : "bg-fgx-red"}`}>
      {texto}
      {tipo === "erro" && (
        <button onClick={aoFechar} className="ml-3 underline text-[12px] opacity-80">fechar</button>
      )}
    </div>
  );
}

export function Carregando({ o }: { o: string }) {
  return <div className="cartao p-10 text-center text-ink-3 text-sm">Carregando {o}…</div>;
}

export function Vazio({ children }: { children: ReactNode }) {
  return <div className="cartao p-11 text-center text-ink-3 text-sm leading-relaxed">{children}</div>;
}

export function ErroNaTela({ erro, aoTentar }: { erro: string; aoTentar?: () => void }) {
  return (
    <div className="cartao p-8 text-center">
      <p className="text-fgx-red font-semibold mb-2">Não foi possível carregar</p>
      <p className="text-ink-3 text-sm mb-4">{erro}</p>
      {aoTentar && <button className="btn-contorno btn-p" onClick={aoTentar}>Tentar de novo</button>}
    </div>
  );
}
