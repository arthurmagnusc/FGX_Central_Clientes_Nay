import { useState, type ReactNode } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { lerSessao, limparSessao, trocarNome } from "../lib/sessao";

export interface ItemNav { para: string; nome: string; contador?: number; icone: ReactNode }

/**
 * Casca comum. `variante` muda só a cor da barra lateral: vinho no portal do
 * cliente, preta no painel interno. É proposital — quem opera os dois lados
 * precisa saber num relance onde está antes de clicar em publicar.
 */
export function Layout(
  { itens, titulo, subtitulo, trilha, children, variante = "cliente" }:
  { itens: ItemNav[]; titulo: string; subtitulo: string; trilha: ReactNode;
    children: ReactNode; variante?: "cliente" | "admin" },
) {
  const [aberto, setAberto] = useState(false);
  const sessao = lerSessao();
  const navegar = useNavigate();

  const fundoLateral = variante === "cliente"
    ? "bg-[linear-gradient(168deg,#8E1A18_0%,#7E131C_45%,#5E0E15_100%)]"
    : "bg-[linear-gradient(170deg,#2A2523_0%,#1A1716_55%,#100E0D_100%)]";

  function sair() {
    limparSessao();
    navegar(variante === "cliente" ? `/c/${sessao?.cliente?.slug ?? ""}` : "/admin", { replace: true });
  }

  function naoSouEu() {
    const nome = window.prompt("Quem está usando o portal agora?", sessao?.pessoa_nome ?? "");
    if (nome && nome.trim().length > 1) { trocarNome(nome.trim()); window.location.reload(); }
  }

  return (
    <div className="flex min-h-screen">
      <aside className={`w-[288px] shrink-0 text-white flex flex-col p-5 sticky top-0 h-screen z-40
          max-lg:fixed max-lg:left-0 max-lg:transition-transform max-lg:shadow-2xl
          ${aberto ? "max-lg:translate-x-0" : "max-lg:-translate-x-full"} ${fundoLateral}`}>
        <div className="flex items-center gap-3 px-1 pb-5">
          <div className="w-11 h-11 rounded-xl grid place-items-center font-titulo font-black text-sm
             bg-[linear-gradient(140deg,#C4331F,#E77938)]">FGX</div>
          <div>
            <div className="font-titulo font-bold text-[16px] leading-tight">{titulo}</div>
            <div className="text-[9.5px] tracking-[1.4px] opacity-60 uppercase mt-0.5">{subtitulo}</div>
          </div>
        </div>

        <div className="text-[9.5px] tracking-[1.5px] opacity-50 uppercase mx-1 mt-5 mb-2.5">
          {variante === "cliente" ? "Workspace" : "Produção"}
        </div>
        <nav className="flex flex-col gap-0.5">
          {itens.map((i) => (
            <NavLink key={i.para} to={i.para} onClick={() => setAberto(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3.5 py-3 rounded-xl text-[14.5px] transition relative
                 ${isActive ? "bg-white/[.13] text-white font-semibold" : "text-white/75 hover:bg-white/[.09] hover:text-white"}`}>
              {i.icone}<span>{i.nome}</span>
              {!!i.contador && (
                <span className="ml-auto text-[11.5px] font-semibold bg-white/[.16] px-2 py-px rounded-full min-w-[24px] text-center">
                  {i.contador}
                </span>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="mt-auto flex flex-col gap-0.5">
          {variante === "cliente" && (
            <div className="bg-black/[.16] border border-white/[.09] rounded-xl p-3.5 mb-3">
              <div className="text-[13px] font-semibold">Ambiente protegido</div>
              <div className="text-[11px] opacity-60 leading-snug mt-0.5">Conteúdo exclusivo deste contrato</div>
            </div>
          )}
          <button onClick={sair}
            className="flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-[13.5px] text-white/60 hover:bg-white/10 hover:text-white text-left">
            Sair
          </button>
        </div>
      </aside>

      <main className="flex-1 min-w-0">
        <div className="flex items-center gap-3.5 px-8 py-3.5 bg-white/75 backdrop-blur border-b border-linha sticky top-0 z-30 max-lg:px-4">
          <button onClick={() => setAberto(!aberto)} aria-label="Menu"
            className="lg:hidden w-9 h-9 rounded-lg border border-linha bg-white grid place-items-center">☰</button>
          <div className="flex items-center gap-2 text-sm text-ink-3">{trilha}</div>
          <div className="ml-auto flex items-center gap-3 text-[12.5px]">
            {variante === "cliente" ? (
              <>
                <span className="text-ink-3">Você é <b className="text-ink">{sessao?.pessoa_nome}</b></span>
                <button onClick={naoSouEu} className="underline text-ink-3 hover:text-ink">não sou eu</button>
              </>
            ) : (
              <span className="text-ink-3">Equipe FGX</span>
            )}
          </div>
        </div>
        <div className="px-8 pb-20 pt-7 max-w-[1360px] max-lg:px-4">{children}</div>
      </main>
    </div>
  );
}
