import { banco, chamarFuncao } from "./supabase";
import type {
  Ajuste, Bloco, Ciclo, Cliente, Comentario, EtapaTrilha, Fonte, Peca, Raciocinio, TipoAjuste,
} from "./tipos";
import type { BlocoRascunho } from "./blocos";

/* ---------------------------------------------------------- catálogos */
export async function clientes(): Promise<Cliente[]> {
  const { data, error } = await banco().from("cliente").select("id, nome, slug, tom_de_voz, areas_chave, regra_base_ref, ativo").order("nome");
  if (error) throw error;
  return (data ?? []) as unknown as Cliente[];
}

export async function editoriasDoCliente(clienteId: string) {
  const { data, error } = await banco().from("editoria").select("id, nome").eq("cliente_id", clienteId).order("ordem");
  if (error) throw error;
  return data ?? [];
}

export async function pilaresDoCliente(clienteId: string) {
  const { data, error } = await banco().from("pilar").select("id, nome").eq("cliente_id", clienteId).order("ordem");
  if (error) throw error;
  return data ?? [];
}

/** Só os canais contratados por aquele cliente entram no formulário de peça. */
export async function canaisDoCliente(clienteId: string) {
  const { data, error } = await banco()
    .from("cliente_canal").select("canal:canal_codigo (codigo, nome, limite_caracteres_padrao)")
    .eq("cliente_id", clienteId);
  if (error) throw error;
  return (data ?? []).map((l: any) => l.canal);
}

export async function ciclosDoCliente(clienteId: string): Promise<Ciclo[]> {
  const { data, error } = await banco().from("ciclo").select("*")
    .eq("cliente_id", clienteId).order("mes_referencia", { ascending: false });
  if (error) throw error;
  return (data ?? []) as Ciclo[];
}

export async function pecasDoCicloAdmin(cicloId: string): Promise<Peca[]> {
  const { data, error } = await banco().from("peca_completa").select("*").eq("ciclo_id", cicloId).order("ordem");
  if (error) throw error;
  return (data ?? []) as Peca[];
}

export async function publicarCiclo(cicloId: string, publicar: boolean) {
  const { error } = await banco().from("ciclo").update({
    status: publicar ? "publicado" : "rascunho",
    publicado_em: publicar ? new Date().toISOString() : null,
  }).eq("id", cicloId);
  if (error) throw error;
}

/* -------------------------------------------------------------- peça */
export interface RascunhoPeca {
  id?: string;
  ciclo_id: string;
  tema: string;
  area_direito: string;
  canal_codigo: string;
  formato: string;
  editoria_id: string | null;
  pilar_id: string | null;
  funil: string | null;
  gancho_texto: string;
  gancho_tipo: string | null;
  gancho_url: string;
  gancho_data: string | null;
}

/**
 * Salva peça + blocos + trilha + raciocínios + fontes.
 *
 * Blocos são apagados e reinseridos: o editor trabalha com a lista inteira e
 * reordena livremente, então casar id a id daria mais chance de erro do que
 * de ganho. O custo é perder o vínculo de comentário com o bloco quando a
 * peça é reeditada — por isso o `preservarComentarios` abaixo.
 */
export async function salvarPeca(
  rascunho: RascunhoPeca,
  blocos: BlocoRascunho[],
  trilha: { passo: string; descricao: string }[],
  raciocinios: { titulo: string; texto: string }[],
  fontes: { titulo: string; url: string; tipo: string; data_publicacao: string | null }[],
): Promise<string> {
  const db = banco();
  const campos = { ...rascunho };
  delete (campos as any).id;

  let pecaId = rascunho.id;
  if (pecaId) {
    const { error } = await db.from("peca").update(campos).eq("id", pecaId);
    if (error) throw error;
  } else {
    const { data, error } = await db.from("peca").insert(campos).select("id").single();
    if (error) throw error;
    pecaId = data.id as string;
  }

  await preservarComentarios(pecaId!, blocos);

  await db.from("trilha_producao").delete().eq("peca_id", pecaId);
  if (trilha.length) {
    const { error } = await db.from("trilha_producao")
      .insert(trilha.map((t, i) => ({ peca_id: pecaId, ordem: i + 1, passo: t.passo, descricao: t.descricao })));
    if (error) throw error;
  }

  await db.from("peca_raciocinio").delete().eq("peca_id", pecaId);
  if (raciocinios.length) {
    const { error } = await db.from("peca_raciocinio")
      .insert(raciocinios.map((r, i) => ({ peca_id: pecaId, ordem: i + 1, titulo: r.titulo, texto: r.texto })));
    if (error) throw error;
  }

  await db.from("fonte").delete().eq("peca_id", pecaId);
  if (fontes.length) {
    const { error } = await db.from("fonte").insert(fontes.map((f, i) => ({
      peca_id: pecaId, ordem: i + 1, titulo: f.titulo, url: f.url || null,
      tipo: f.tipo || null, data_publicacao: f.data_publicacao || null,
    })));
    if (error) throw error;
  }

  return pecaId!;
}

/**
 * Reescreve os blocos mantendo os comentários vivos.
 * Blocos cujo texto não mudou são reaproveitados pelo id; os demais são
 * recriados, e os comentários que apontavam para eles passam a apontar para
 * a peça (peca_bloco_id = null) em vez de sumir. Comentário do cliente não
 * se perde nunca — nem quando a peça é reescrita.
 */
async function preservarComentarios(pecaId: string, blocos: BlocoRascunho[]) {
  const db = banco();
  const { data: atuais } = await db.from("peca_bloco").select("id, conteudo, ordem").eq("peca_id", pecaId).order("ordem");
  const antigos = (atuais ?? []) as Bloco[];

  const casados = new Map<number, string>(); // índice novo -> id antigo
  const usados = new Set<string>();
  blocos.forEach((b, i) => {
    const igual = antigos.find((a) => a.conteudo === b.conteudo && !usados.has(a.id));
    if (igual) { casados.set(i, igual.id); usados.add(igual.id); }
  });

  const aRemover = antigos.filter((a) => !usados.has(a.id)).map((a) => a.id);
  if (aRemover.length) {
    await db.from("comentario").update({ peca_bloco_id: null }).in("peca_bloco_id", aRemover);
    await db.from("peca_bloco").delete().in("id", aRemover);
  }

  for (let i = 0; i < blocos.length; i++) {
    const b = blocos[i];
    const idAntigo = casados.get(i);
    if (idAntigo) {
      await db.from("peca_bloco").update({ ordem: i + 1, titulo: b.titulo || null }).eq("id", idAntigo);
    } else {
      const { error } = await db.from("peca_bloco")
        .insert({ peca_id: pecaId, ordem: i + 1, titulo: b.titulo || null, conteudo: b.conteudo });
      if (error) throw error;
    }
  }
}

export async function carregarPecaParaEdicao(pecaId: string) {
  const db = banco();
  const [p, b, t, r, f] = await Promise.all([
    db.from("peca").select("*").eq("id", pecaId).single(),
    db.from("peca_bloco").select("*").eq("peca_id", pecaId).order("ordem"),
    db.from("trilha_producao").select("*").eq("peca_id", pecaId).order("ordem"),
    db.from("peca_raciocinio").select("*").eq("peca_id", pecaId).order("ordem"),
    db.from("fonte").select("*").eq("peca_id", pecaId).order("ordem"),
  ]);
  if (p.error) throw p.error;
  return {
    peca: p.data,
    blocos: ((b.data ?? []) as Bloco[]).map((x) => ({ titulo: x.titulo ?? "", conteudo: x.conteudo })),
    trilha: ((t.data ?? []) as EtapaTrilha[]).map((x) => ({ passo: x.passo, descricao: x.descricao ?? "" })),
    raciocinios: ((r.data ?? []) as Raciocinio[]).map((x) => ({ titulo: x.titulo, texto: x.texto })),
    fontes: ((f.data ?? []) as Fonte[]).map((x) => ({
      titulo: x.titulo, url: x.url ?? "", tipo: x.tipo ?? "", data_publicacao: x.data_publicacao,
    })),
  };
}

/* ------------------------------------------------- comentários e ajustes */
export async function comentariosDoCiclo(cicloId: string) {
  const { data, error } = await banco()
    .from("comentario")
    .select("*, peca:peca_id!inner (id, tema, formato, ciclo_id), bloco:peca_bloco_id (id, ordem, titulo, conteudo)")
    .eq("peca.ciclo_id", cicloId)
    .order("criado_em", { ascending: false });
  if (error) throw error;
  return (data ?? []) as unknown as (Comentario & {
    peca: { id: string; tema: string; formato: string };
    bloco: { id: string; ordem: number; titulo: string | null; conteudo: string } | null;
  })[];
}

export async function marcarTratado(comentarioId: string, tratado: boolean) {
  const { error } = await banco().from("comentario").update({ tratado }).eq("id", comentarioId);
  if (error) throw error;
}

export async function registrarAjuste(
  pecaId: string, comentarioId: string | null, descricao: string, tipo: TipoAjuste,
): Promise<Ajuste> {
  const db = banco();
  const { data, error } = await db.from("ajuste")
    .insert({ peca_id: pecaId, comentario_id: comentarioId, descricao, tipo })
    .select("*").single();
  if (error) throw error;
  if (comentarioId) await marcarTratado(comentarioId, true);
  return data as Ajuste;
}

export async function ajustes(): Promise<(Ajuste & { peca: { tema: string } })[]> {
  const { data, error } = await banco()
    .from("ajuste").select("*, peca:peca_id (tema)").order("criado_em", { ascending: false });
  if (error) throw error;
  return (data ?? []) as any;
}

export async function marcarAjusteAplicado(ajusteId: string) {
  const { error } = await banco().from("ajuste").update({ status_avaliacao: "aplicado" }).eq("id", ajusteId);
  if (error) throw error;
}

/* --------------------------------------------------- documento aditivo */
export function montarAditivo(cliente: string, tema: string, descricao: string) {
  const hoje = new Date().toLocaleDateString("pt-BR");
  return `# Documento aditivo — ${cliente}

**Origem:** comentário do cliente na peça "${tema}"
**Classificação:** ajuste estrutural
**Registrado em:** ${hoje}

## Regra acrescentada

${descricao}

## Aplicação

Vale para todas as peças seguintes deste cliente, nas editorias em que o tema incidir.
Este documento passa a integrar a regra-base usada na produção.
`;
}

export async function salvarAditivo(clienteId: string, ajusteId: string, titulo: string, conteudo: string) {
  const { error } = await banco().from("documento_aditivo")
    .insert({ cliente_id: clienteId, ajuste_id: ajusteId, titulo, conteudo });
  if (error) throw error;
}

export async function aditivos(clienteId: string) {
  const { data, error } = await banco().from("documento_aditivo")
    .select("*").eq("cliente_id", clienteId).order("criado_em", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

/* ------------------------------------------------ encaminhar avaliação */
export async function enviarParaAvaliacao(ajusteId: string) {
  return chamarFuncao<{ modo: "webhook" | "download"; pacote?: unknown; resultado?: string }>(
    "enviar-ajuste", { method: "POST", body: JSON.stringify({ ajuste_id: ajusteId }) });
}

export function baixarJson(nome: string, conteudo: unknown) {
  const blob = new Blob([JSON.stringify(conteudo, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = nome; a.click();
  URL.revokeObjectURL(url);
}

export function baixarTexto(nome: string, conteudo: string) {
  const blob = new Blob([conteudo], { type: "text/markdown" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = nome; a.click();
  URL.revokeObjectURL(url);
}
