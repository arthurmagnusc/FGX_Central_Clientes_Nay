import type { SessaoAtiva } from "./tipos";

// O JWT fica em sessionStorage, não em localStorage: ele morre ao fechar a
// aba, o que reduz a janela de exposição num computador compartilhado.
// Ver HANDOFF.md, seção "Onde guardamos o token" — há a alternativa de
// cookie httpOnly, com o custo de rotear todas as leituras por Functions.
const CHAVE = "portal-fgx:sessao";

let emMemoria: SessaoAtiva | null = null;

export function lerSessao(): SessaoAtiva | null {
  if (emMemoria) return emMemoria;
  try {
    const bruto = sessionStorage.getItem(CHAVE);
    if (!bruto) return null;
    const s = JSON.parse(bruto) as SessaoAtiva;
    if (new Date(s.expira_em) < new Date()) { limparSessao(); return null; }
    emMemoria = s;
    return s;
  } catch { return null; }
}

export function gravarSessao(s: SessaoAtiva) {
  emMemoria = s;
  sessionStorage.setItem(CHAVE, JSON.stringify(s));
}

export function limparSessao() {
  emMemoria = null;
  sessionStorage.removeItem(CHAVE);
}

// Trocar o nome sem sair: o "não sou eu" do cabeçalho.
export function trocarNome(nome: string) {
  const s = lerSessao();
  if (!s) return;
  gravarSessao({ ...s, pessoa_nome: nome });
}
