import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { lerSessao } from "./sessao";

const url = import.meta.env.VITE_SUPABASE_URL as string;
const anon = import.meta.env.VITE_SUPABASE_ANON_KEY as string;
export const URL_FUNCTIONS = import.meta.env.VITE_FUNCTIONS_URL as string;

if (!url || !anon) {
  throw new Error("Faltam VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY. Veja .env.example.");
}

let cache: { token: string | null; cliente: SupabaseClient } | null = null;

// O token da sessão entra como Authorization. É ele que as políticas de RLS
// leem para descobrir de que cliente é a requisição — por isso nenhuma
// consulta no front precisa (nem deve) filtrar por cliente_id na mão.
export function banco(): SupabaseClient {
  const token = lerSessao()?.token ?? null;
  if (cache && cache.token === token) return cache.cliente;
  const cliente = createClient(url, anon, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: token ? { Authorization: `Bearer ${token}` } : {} },
  });
  cache = { token, cliente };
  return cliente;
}

export async function chamarFuncao<T>(nome: string, opcoes: RequestInit = {}): Promise<T> {
  const token = lerSessao()?.token;
  const r = await fetch(`${URL_FUNCTIONS}/${nome}`, {
    ...opcoes,
    headers: {
      "Content-Type": "application/json",
      apikey: anon,
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(opcoes.headers ?? {}),
    },
  });
  const corpo = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(corpo?.erro ?? "Falha na requisição.");
  return corpo as T;
}
