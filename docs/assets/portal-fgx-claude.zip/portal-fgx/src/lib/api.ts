import { banco, chamarFuncao, URL_FUNCTIONS } from "./supabase";
import { gravarSessao } from "./sessao";
import type {
  Ajuste, Aprovacao, Bloco, Canal, Ciclo, Cliente, Comentario, Entregavel,
  EtapaTrilha, Fonte, Peca, Raciocinio, Relatorio, SessaoAtiva,
} from "./tipos";

/* ------------------------------------------------------------ entrada */
export async function entrar(slug: string, senha: string, nome: string): Promise<SessaoAtiva> {
  const r = await fetch(`${URL_FUNCTIONS}/entrar`, {
    method: "POST",
    headers: { "Content-Type": "application/json", apikey: import.meta.env.VITE_SUPABASE_ANON_KEY },
    body: JSON.stringify({ slug, senha, nome }),
  });
  const corpo = await r.json();
  if (!r.ok) throw new Error(corpo?.erro ?? "Não foi possível entrar.");
  const sessao: SessaoAtiva = { ...corpo, is_admin: false };
  gravarSessao(sessao);
  return sessao;
}

export async function entrarAdmin(senha: string): Promise<SessaoAtiva> {
  const r = await fetch(`${URL_FUNCTIONS}/entrar-admin`, {
    method: "POST",
    headers: { "Content-Type": "application/json", apikey: import.meta.env.VITE_SUPABASE_ANON_KEY },
    body: JSON.stringify({ senha }),
  });
  const corpo = await r.json();
  if (!r.ok) throw new Error(corpo?.erro ?? "Não foi possível entrar.");
  const sessao: SessaoAtiva = { ...corpo, pessoa_nome: corpo.admin.nome, is_admin: true };
  gravarSessao(sessao);
  return sessao;
}

/* ------------------------------------------------------------- leitura */
// Nenhuma destas funções filtra por cliente_id: quem faz isso é o RLS.
// Se alguma passar a filtrar na mão, é sinal de que a política está errada.

export async function meuCliente(): Promise<Cliente> {
  const { data, error } = await banco().from("meu_cliente").select("*").single();
  if (error) throw error;
  return data as Cliente;
}

export async function canais(): Promise<Canal[]> {
  const { data, error } = await banco()
    .from("cliente_canal").select("canal:canal_codigo (codigo, nome, limite_caracteres_padrao)");
  if (error) throw error;
  return (data ?? []).map((l: any) => l.canal);
}

export async function ciclos(): Promise<Ciclo[]> {
  const { data, error } = await banco()
    .from("ciclo").select("*").order("mes_referencia", { ascending: false });
  if (error) throw error;
  return (data ?? []) as Ciclo[];
}

export async function pecasDoCiclo(cicloId: string): Promise<Peca[]> {
  const { data, error } = await banco()
    .from("peca_completa").select("*").eq("ciclo_id", cicloId).order("ordem");
  if (error) throw error;
  return (data ?? []) as Peca[];
}

export async function peca(id: string): Promise<Peca> {
  const { data, error } = await banco().from("peca_completa").select("*").eq("id", id).single();
  if (error) throw error;
  return data as Peca;
}

/** Tudo o que a página da peça precisa, em uma ida ao banco por tabela. */
export async function conteudoDaPeca(pecaId: string) {
  const db = banco();
  const [b, r, t, f, c, a, aj] = await Promise.all([
    db.from("peca_bloco").select("*").eq("peca_id", pecaId).order("ordem"),
    db.from("peca_raciocinio").select("*").eq("peca_id", pecaId).order("ordem"),
    db.from("trilha_producao").select("*").eq("peca_id", pecaId).order("ordem"),
    db.from("fonte").select("*").eq("peca_id", pecaId).order("ordem"),
    db.from("comentario").select("*").eq("peca_id", pecaId).order("criado_em"),
    db.from("aprovacao").select("*").eq("peca_id", pecaId).order("criado_em", { ascending: false }),
    db.from("ajuste").select("*").eq("peca_id", pecaId).order("criado_em"),
  ]);
  const falha = [b, r, t, f, c, a, aj].find((x) => x.error);
  if (falha?.error) throw falha.error;
  return {
    blocos: (b.data ?? []) as Bloco[],
    raciocinios: (r.data ?? []) as Raciocinio[],
    trilha: (t.data ?? []) as EtapaTrilha[],
    fontes: (f.data ?? []) as Fonte[],
    comentarios: (c.data ?? []) as Comentario[],
    aprovacoes: (a.data ?? []) as Aprovacao[],
    ajustes: (aj.data ?? []) as Ajuste[],
  };
}

export async function entregaveis(): Promise<Entregavel[]> {
  const { data, error } = await banco()
    .from("entregavel").select("*").order("publicado_em", { ascending: false });
  if (error) throw error;
  return (data ?? []) as Entregavel[];
}

export async function relatorios(): Promise<Relatorio[]> {
  const { data, error } = await banco()
    .from("relatorio").select("*").order("emitido_em", { ascending: false });
  if (error) throw error;
  return (data ?? []) as Relatorio[];
}

/* ------------------------------------------------------------- escrita */
export async function comentar(
  pecaId: string, texto: string, autorNome: string, blocoId?: string | null,
): Promise<Comentario> {
  const { data, error } = await banco().from("comentario").insert({
    peca_id: pecaId,
    peca_bloco_id: blocoId ?? null,
    autor_nome: autorNome,   // conferido pelo RLS contra o nome da sessão
    autor_tipo: "cliente",
    texto,
  }).select("*").single();
  if (error) throw error;
  return data as Comentario;
}

export async function aprovarPeca(pecaId: string, autorNome: string) {
  const db = banco();
  const { error: e1 } = await db.from("aprovacao")
    .insert({ peca_id: pecaId, autor_nome: autorNome, acao: "aprovou" });
  if (e1) throw e1;
  const { error: e2 } = await db.from("peca").update({ status: "aprovada" }).eq("id", pecaId);
  if (e2) throw e2;
}

export async function solicitarAjuste(pecaId: string, autorNome: string) {
  const db = banco();
  const { error: e1 } = await db.from("aprovacao")
    .insert({ peca_id: pecaId, autor_nome: autorNome, acao: "solicitou_ajuste" });
  if (e1) throw e1;
  const { error: e2 } = await db.from("peca").update({ status: "em_revisao" }).eq("id", pecaId);
  if (e2) throw e2;
}

/* ------------------------------------------------------------ arquivos */
export async function baixarEntregavel(id: string) {
  const { url, nome_arquivo } = await chamarFuncao<{ url: string; nome_arquivo: string }>(
    `baixar-entregavel?id=${encodeURIComponent(id)}`,
  );
  const a = document.createElement("a");
  a.href = url; a.download = nome_arquivo; a.rel = "noopener";
  document.body.appendChild(a); a.click(); a.remove();
}
