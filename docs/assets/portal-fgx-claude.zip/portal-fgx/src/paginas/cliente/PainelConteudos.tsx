import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ciclos, pecasDoCiclo } from "../../lib/api";
import { mesBr, NOME_FORMATO } from "../../lib/formato";
import { BarraStatus, Carregando, ErroNaTela, Pilula, Vazio } from "../../componentes/Basicos";
import type { Ciclo, Peca, StatusPeca } from "../../lib/tipos";

export default function PainelConteudos() {
  const { slug = "" } = useParams();
  const [lista, setLista] = useState<Ciclo[]>([]);
  const [cicloId, setCicloId] = useState("");
  const [pecas, setPecas] = useState<Peca[]>([]);
  const [canal, setCanal] = useState("todos");
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState("");

  async function carregar() {
    setCarregando(true); setErro("");
    try {
      const cs = await ciclos();
      setLista(cs);
      const alvo = cicloId || cs[0]?.id || "";
      setCicloId(alvo);
      setPecas(alvo ? await pecasDoCiclo(alvo) : []);
    } catch (e) { setErro((e as Error).message); }
    finally { setCarregando(false); }
  }
  useEffect(() => { carregar(); /* eslint-disable-next-line */ }, [cicloId]);

  const contagem = useMemo(() => {
    const c: Record<StatusPeca, number> = { pendente: 0, em_revisao: 0, ajustada: 0, aprovada: 0 };
    pecas.forEach((p) => c[p.status]++);
    return c;
  }, [pecas]);

  const canaisDisponiveis = useMemo(
    () => Array.from(new Map(pecas.map((p) => [p.canal_codigo, p.canal_nome])).entries()), [pecas]);

  const visiveis = pecas.filter((p) => canal === "todos" || p.canal_codigo === canal);
  const ciclo = lista.find((c) => c.id === cicloId);

  if (carregando) return <Carregando o="o ciclo" />;
  if (erro) return <ErroNaTela erro={erro} aoTentar={carregar} />;
  if (!ciclo) return <Vazio>Nenhum ciclo publicado ainda.<br />Assim que a FGX publicar, ele aparece aqui.</Vazio>;

  const totalComentarios = pecas.reduce((a, p) => a + Number(p.total_comentarios), 0);

  return (
    <>
      <header className="mb-7">
        <div className="flex items-center gap-2 text-[11.5px] font-bold tracking-[1.4px] uppercase text-fgx-red mb-3.5">
          Ciclo de {mesBr(ciclo.mes_referencia)}
        </div>
        <h1 className="text-[38px] max-lg:text-[28px] font-bold leading-[1.08] tracking-tight mb-4">Painel de Conteúdos</h1>
        <p className="text-base text-ink-2 max-w-[600px]">
          Os conteúdos técnicos do mês, para leitura e validação. O que se valida aqui é o <b className="text-fgx-red font-medium">texto</b> —
          a arte segue no fluxo de sempre.
        </p>
      </header>

      <div className="cartao p-6 mb-6">
        <div className="flex items-start gap-4 flex-wrap mb-5">
          <div>
            <span className="etiqueta">Ciclo {ciclo.status}</span>
            <h2 className="text-[22px] font-bold mt-2 capitalize">{mesBr(ciclo.mes_referencia)}</h2>
          </div>
          {lista.length > 1 && (
            <div className="ml-auto">
              <label className="rotulo" htmlFor="ciclo">Ciclo</label>
              <select id="ciclo" className="campo py-2" value={cicloId} onChange={(e) => setCicloId(e.target.value)}>
                {lista.map((c) => <option key={c.id} value={c.id}>{mesBr(c.mes_referencia)}</option>)}
              </select>
            </div>
          )}
        </div>
        <div className="grid grid-cols-[repeat(auto-fit,minmax(125px,1fr))] gap-4 mb-5">
          <Stat n={pecas.length} rotulo="Peças no ciclo" />
          <Stat n={contagem.aprovada} rotulo="Aprovadas" cor="text-fgx-green" />
          <Stat n={pecas.length - contagem.aprovada} rotulo="Aguardando você" cor="text-fgx-blue" />
          <Stat n={totalComentarios} rotulo="Comentários" />
        </div>
        {pecas.length > 0 && <BarraStatus contagem={contagem} total={pecas.length} />}
      </div>

      <div className="flex gap-2 flex-wrap mb-5">
        <Chip on={canal === "todos"} onClick={() => setCanal("todos")}>Todos <b>{pecas.length}</b></Chip>
        {canaisDisponiveis.map(([codigo, nome]) => (
          <Chip key={codigo} on={canal === codigo} onClick={() => setCanal(codigo)}>
            {nome} <b>{pecas.filter((p) => p.canal_codigo === codigo).length}</b>
          </Chip>
        ))}
      </div>

      {visiveis.length === 0 ? <Vazio>Nenhuma peça neste filtro.</Vazio> : (
        <div className="grid grid-cols-[repeat(auto-fill,minmax(320px,1fr))] gap-4">
          {visiveis.map((p) => (
            <Link key={p.id} to={`/c/${slug}/conteudos/${p.id}`}
              className="cartao p-5 flex flex-col hover:border-fgx-orange hover:-translate-y-0.5 transition">
              <div className="flex items-start gap-2 mb-2.5">
                <span className="text-[10.5px] font-bold tracking-wider uppercase text-ink-3">{p.editoria_nome ?? "—"}</span>
                <span className="ml-auto"><Pilula status={p.status} /></span>
              </div>
              <h3 className="text-[16.5px] font-bold leading-snug">{p.tema}</h3>
              <div className="flex flex-wrap gap-2 my-3">
                <span className="etiqueta">{p.canal_nome}</span>
                <span className="etiqueta-n">{NOME_FORMATO[p.formato]}</span>
                {p.funil && <span className="etiqueta-n capitalize">Funil: {p.funil}</span>}
              </div>
              <div className="flex items-center gap-3 text-xs text-ink-3 border-t border-linha pt-3.5 mt-auto">
                <span>{p.area_direito}</span>
                <span className="ml-auto">{p.total_comentarios} {Number(p.total_comentarios) === 1 ? "comentário" : "comentários"}</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </>
  );
}

function Stat({ n, rotulo, cor = "" }: { n: number; rotulo: string; cor?: string }) {
  return (
    <div>
      <div className={`font-titulo text-[28px] font-bold leading-none ${cor}`}>{n}</div>
      <div className="text-[11.5px] text-ink-3 mt-1">{rotulo}</div>
    </div>
  );
}

function Chip({ on, onClick, children }: { on: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick}
      className={`flex items-center gap-2 px-4 py-2 border rounded-full text-[13px] font-semibold transition
        ${on ? "border-fgx-red text-fgx-red bg-fgx-red/5" : "border-linha bg-white text-ink-2 hover:border-ink-3"}`}>
      {children}
    </button>
  );
}
