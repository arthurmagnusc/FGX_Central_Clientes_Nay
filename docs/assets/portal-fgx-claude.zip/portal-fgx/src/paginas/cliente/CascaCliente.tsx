import { Navigate, Outlet, useLocation, useParams } from "react-router-dom";
import { Layout, type ItemNav } from "../../componentes/Layout";
import { lerSessao } from "../../lib/sessao";

const ic = (d: string) => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" dangerouslySetInnerHTML={{ __html: d }} />
);

export default function CascaCliente() {
  const { slug = "" } = useParams();
  const sessao = lerSessao();
  const local = useLocation();

  if (!sessao || sessao.is_admin) return <Navigate to={`/c/${slug}`} replace />;

  const itens: ItemNav[] = [
    { para: `/c/${slug}/visao-geral`, nome: "Visão geral", icone: ic('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>') },
    { para: `/c/${slug}/entregas`, nome: "Entregas", icone: ic('<path d="M4 7a2 2 0 012-2h4l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H6a2 2 0 01-2-2z"/>') },
    { para: `/c/${slug}/relatorios`, nome: "Relatórios", icone: ic('<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6"/>') },
    { para: `/c/${slug}/conteudos`, nome: "Painel de Conteúdos", icone: ic('<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18"/>') },
  ];

  const atual = itens.find((i) => local.pathname.startsWith(i.para));
  const trilha = (
    <>
      <span>{sessao.cliente?.nome}</span><span>/</span>
      <b className="text-ink font-semibold">{atual?.nome ?? "Peça"}</b>
    </>
  );

  return (
    <Layout itens={itens} titulo="Portal do Cliente" subtitulo="Strategic Solutions" trilha={trilha}>
      <Outlet />
    </Layout>
  );
}
