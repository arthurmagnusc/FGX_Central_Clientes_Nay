import { useEffect, useState } from "react";
import { chamarFuncao } from "../../lib/supabase";
import { relatorios } from "../../lib/api";
import { dataBr } from "../../lib/formato";
import { Aviso, Carregando, ErroNaTela, Vazio } from "../../componentes/Basicos";
import type { Relatorio } from "../../lib/tipos";

export default function Relatorios() {
  const [itens, setItens] = useState<Relatorio[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState("");
  const [aviso, setAviso] = useState<{ texto: string; tipo: "ok" | "erro" } | null>(null);

  async function carregar() {
    setCarregando(true); setErro("");
    try { setItens(await relatorios()); }
    catch (e) { setErro((e as Error).message); }
    finally { setCarregando(false); }
  }
  useEffect(() => { carregar(); }, []);

  // O relatório é uma peça acabada, produzida fora do portal. Abrimos em aba
  // nova em vez de embutir: espremer dentro de outra página só piora a leitura.
  async function abrir(r: Relatorio) {
    if (!r.storage_path) { setAviso({ texto: "Este relatório ainda não tem arquivo publicado.", tipo: "erro" }); return; }
    try {
      const { url } = await chamarFuncao<{ url: string }>(`baixar-relatorio?id=${r.id}`);
      window.open(url, "_blank", "noopener");
    } catch (e) { setAviso({ texto: (e as Error).message, tipo: "erro" }); }
  }

  if (carregando) return <Carregando o="os relatórios" />;
  if (erro) return <ErroNaTela erro={erro} aoTentar={carregar} />;

  return (
    <>
      {aviso && <Aviso texto={aviso.texto} tipo={aviso.tipo} aoFechar={() => setAviso(null)} />}

      <header className="mb-8">
        <div className="text-[11.5px] font-bold tracking-[1.4px] uppercase text-fgx-red mb-3.5">Prestação de contas</div>
        <h1 className="text-[44px] max-lg:text-[30px] font-bold leading-[1.08] tracking-tight mb-4">Relatórios do contrato</h1>
        <p className="text-base text-ink-2 max-w-[640px]">
          A leitura frente a frente entre o escopo contratado e o realizado em cada período, com o volume
          previsto, o publicado e o total produzido em cada frente de trabalho.
        </p>
      </header>

      {itens.length === 0 ? <Vazio>Nenhum relatório publicado ainda.</Vazio> : itens.map((r) => (
        <div key={r.id} className="cartao overflow-hidden mb-5">
          <div className="px-7 py-6 max-lg:px-5">
            <div className="text-[10.5px] font-bold tracking-wider uppercase text-ink-3 mb-2">Relatório de escopo</div>
            <h3 className="text-[19px] font-bold leading-snug">{r.titulo}</h3>
            <div className="text-[13px] text-ink-3 mt-1">
              {r.periodo_inicio && r.periodo_fim && <>Período de {dataBr(r.periodo_inicio)} a {dataBr(r.periodo_fim)} · </>}
              emitido em {dataBr(r.emitido_em)}
            </div>
            {r.resumo && <p className="text-[13.5px] text-ink-2 leading-relaxed mt-3 max-w-[640px]">{r.resumo}</p>}
          </div>
          {r.kpis.length > 0 && (
            <div className="grid grid-cols-[repeat(auto-fit,minmax(150px,1fr))] gap-px bg-linha border-t border-linha">
              {r.kpis.map((k, i) => (
                <div key={i} className="bg-white px-5 py-4">
                  <div className="font-titulo text-[25px] font-bold leading-none">{k.valor}</div>
                  <div className="text-[11.5px] text-ink-3 mt-1.5 leading-snug">{k.rotulo}</div>
                </div>
              ))}
            </div>
          )}
          <div className="px-7 py-4 bg-[#FBFAF9] border-t border-linha flex gap-3 items-center flex-wrap max-lg:px-5">
            <button className="btn-primario btn-p" onClick={() => abrir(r)}>Abrir relatório completo</button>
            {r.secoes.length > 0 && (
              <span className="ml-auto text-xs text-ink-3">{r.secoes.length} seções · {r.secoes.join(" · ")}</span>
            )}
          </div>
        </div>
      ))}
    </>
  );
}
