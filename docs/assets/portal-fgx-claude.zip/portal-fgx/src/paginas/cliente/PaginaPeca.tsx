import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { aprovarPeca, comentar, conteudoDaPeca, peca as buscarPeca, pecasDoCiclo, solicitarAjuste } from "../../lib/api";
import { lerSessao } from "../../lib/sessao";
import { markdownSeguro } from "../../lib/sanitizar";
import {
  dataBr, dataHoraBr, LIMITE_SLIDE, NOME_FORMATO, numeroBr, rotuloBloco, rotuloBotaoComentar,
} from "../../lib/formato";
import { Aviso, Carregando, ErroNaTela, Pilula, Recolhivel } from "../../componentes/Basicos";
import type { Peca } from "../../lib/tipos";

type Conteudo = Awaited<ReturnType<typeof conteudoDaPeca>>;

export default function PaginaPeca() {
  const { slug = "", pecaId = "" } = useParams();
  const navegar = useNavigate();
  const sessao = lerSessao();
  const [p, setP] = useState<Peca | null>(null);
  const [c, setC] = useState<Conteudo | null>(null);
  const [irmas, setIrmas] = useState<Peca[]>([]);
  const [erro, setErro] = useState("");
  const [aviso, setAviso] = useState<{ texto: string; tipo: "ok" | "erro" } | null>(null);
  const [comentandoBloco, setComentandoBloco] = useState<string | null>(null);
  const [rascunhoBloco, setRascunhoBloco] = useState("");
  const [rascunhoGeral, setRascunhoGeral] = useState("");
  const [salvando, setSalvando] = useState(false);

  const carregar = useCallback(async () => {
    setErro("");
    try {
      const peca = await buscarPeca(pecaId);
      setP(peca);
      setC(await conteudoDaPeca(pecaId));
      setIrmas(await pecasDoCiclo(peca.ciclo_id));
    } catch (e) { setErro((e as Error).message); }
  }, [pecaId]);

  useEffect(() => { carregar(); window.scrollTo(0, 0); }, [carregar]);

  if (erro) return <ErroNaTela erro={erro} aoTentar={carregar} />;
  if (!p || !c) return <Carregando o="a peça" />;

  const totalCaracteres = c.blocos.reduce((a, b) => a + b.conteudo.length + (b.titulo?.length ?? 0), 0);
  const acimaDoLimite = p.limite_efetivo != null && totalCaracteres > p.limite_efetivo;
  const indice = irmas.findIndex((x) => x.id === p.id);
  const aprovacao = c.aprovacoes.find((a) => a.acao === "aprovou");

  /**
   * Comentário não pode se perder: o rascunho só sai do campo depois que o
   * servidor confirma. Se falhar, o texto continua lá e o botão volta.
   */
  async function enviarComentario(blocoId: string | null, texto: string) {
    if (!texto.trim()) { setAviso({ texto: "Escreva o comentário antes de enviar.", tipo: "erro" }); return; }
    setSalvando(true);
    try {
      await comentar(p!.id, texto.trim(), sessao!.pessoa_nome, blocoId);
      setC(await conteudoDaPeca(p!.id));
      if (blocoId) { setComentandoBloco(null); setRascunhoBloco(""); } else { setRascunhoGeral(""); }
      setAviso({ texto: "Comentário registrado", tipo: "ok" });
    } catch (e) {
      setAviso({ texto: `Não deu para salvar: ${(e as Error).message}. Seu texto continua aqui.`, tipo: "erro" });
    } finally { setSalvando(false); }
  }

  async function aprovar() {
    setSalvando(true);
    try {
      await aprovarPeca(p!.id, sessao!.pessoa_nome);
      await carregar();
      setAviso({ texto: `Peça aprovada por ${sessao!.pessoa_nome}`, tipo: "ok" });
    } catch (e) { setAviso({ texto: (e as Error).message, tipo: "erro" }); }
    finally { setSalvando(false); }
  }

  async function pedirAjuste() {
    setSalvando(true);
    try {
      await solicitarAjuste(p!.id, sessao!.pessoa_nome);
      await carregar();
      setAviso({ texto: "Pedido de ajuste registrado — a equipe FGX foi avisada", tipo: "ok" });
    } catch (e) { setAviso({ texto: (e as Error).message, tipo: "erro" }); }
    finally { setSalvando(false); }
  }

  return (
    <>
      {aviso && <Aviso texto={aviso.texto} tipo={aviso.tipo} aoFechar={() => setAviso(null)} />}

      <div className="grid grid-cols-[1fr_340px] max-xl:grid-cols-1 gap-5 items-start">
        <div>
          <article className="cartao overflow-hidden">
            <header className="px-7 pt-6 pb-5 border-b border-linha max-lg:px-5">
              <div className="flex flex-wrap gap-2 items-center">
                <span className="etiqueta">{p.canal_nome}</span>
                <span className="etiqueta-n">{NOME_FORMATO[p.formato]}</span>
                {p.editoria_nome && <span className="etiqueta-n">{p.editoria_nome}</span>}
                {p.funil && <span className="etiqueta-n capitalize">Funil: {p.funil}</span>}
                <span className="ml-auto"><Pilula status={p.status} /></span>
              </div>
              <h1 className="text-[24px] max-lg:text-[20px] font-bold leading-[1.28] tracking-tight my-3">{p.tema}</h1>
              <div className="flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-ink-3">
                {p.area_direito && <span><b>Área:</b> {p.area_direito}</span>}
                {p.pilar_nome && <span><b>Pilar:</b> {p.pilar_nome}</span>}
              </div>

              {p.gancho_texto && (
                <div className="mt-4 border-l-[3px] border-fgx-orange bg-fgx-orange/[.06] px-4 py-3 rounded-r-xl">
                  <div className="text-[11px] font-bold tracking-wider text-[#8A4A22] mb-1">
                    GANCHO {p.gancho_tipo === "jornalistico" ? "· JORNALÍSTICO" : "· ANALÍTICO"}
                  </div>
                  <div className="text-[14px] leading-relaxed">{p.gancho_texto}</div>
                  {p.gancho_url && (
                    <a href={p.gancho_url} target="_blank" rel="noopener noreferrer"
                      className="text-[12.5px] underline mt-1.5 inline-block">
                      ver a fonte do gancho{p.gancho_data ? ` · ${dataBr(p.gancho_data)}` : ""}
                    </a>
                  )}
                </div>
              )}

              <div className={`text-xs mt-3.5 ${acimaDoLimite ? "text-fgx-red" : "text-ink-3"}`}>
                {p.limite_efetivo
                  ? <><b>{numeroBr(totalCaracteres)}</b> caracteres de <b>{numeroBr(p.limite_efetivo)}</b> do canal
                      {acimaDoLimite ? " — acima do limite" : ""}</>
                  : <><b>{numeroBr(totalCaracteres)}</b> caracteres · sem limite definido para este canal</>}
              </div>

              {aprovacao && (
                <div className="mt-3.5 text-[12.5px] text-[#3F6530] bg-fgx-green/10 px-3 py-2 rounded-lg">
                  Aprovada por <b>{aprovacao.autor_nome}</b> em {dataBr(aprovacao.criado_em)}.
                </div>
              )}
            </header>

            {/* ---- blocos: exibição integral + comentário por bloco ---- */}
            <div className="px-7 pt-2 pb-6 max-lg:px-5">
              {c.blocos.map((b, i) => {
                const doBloco = c.comentarios.filter((x) => x.peca_bloco_id === b.id);
                const excede = p.formato === "carrossel" && b.conteudo.length > LIMITE_SLIDE;
                return (
                  <div key={b.id} id={`bloco-${b.id}`} className="relative py-4 border-b border-dashed border-linha last:border-0 group">
                    <div className="font-titulo text-[11.5px] font-bold text-fgx-orange tracking-wider uppercase mb-2">
                      {rotuloBloco(p, i, c.blocos.length, b.titulo)}
                    </div>
                    {b.titulo && p.formato !== "carrossel" && (
                      <h3 className="text-[17px] font-bold mb-2 leading-snug">{b.titulo}</h3>
                    )}
                    {/* dangerouslySetInnerHTML com markdown já sanitizado — ver lib/sanitizar.ts */}
                    <div className="corpo-bloco prose-fgx"
                      dangerouslySetInnerHTML={{ __html: markdownSeguro(b.conteudo) }} />

                    <div className="flex items-center gap-3 mt-2.5 min-h-[26px]">
                      {p.formato === "carrossel" && (
                        <span className={`text-[11.5px] ${excede ? "text-fgx-red font-semibold" : "text-ink-3"}`}>
                          {b.conteudo.length} caracteres
                        </span>
                      )}
                      {doBloco.length > 0 && (
                        <span className="text-[11.5px] font-semibold text-fgx-blue bg-fgx-blue/10 px-2.5 py-0.5 rounded-full">
                          {doBloco.length} {doBloco.length === 1 ? "comentário" : "comentários"}
                        </span>
                      )}
                      <button
                        onClick={() => { setComentandoBloco(b.id); setRascunhoBloco(""); }}
                        className="text-xs font-semibold text-fgx-red px-2.5 py-1 rounded-md border border-transparent
                                   opacity-0 group-hover:opacity-100 group-hover:border-fgx-red/25 focus:opacity-100
                                   max-lg:opacity-100 max-lg:border-fgx-red/25 transition">
                        {rotuloBotaoComentar(p.formato)}
                      </button>
                    </div>

                    {doBloco.length > 0 && (
                      <div className="mt-3 flex flex-col gap-2">
                        {doBloco.map((cm) => (
                          <div key={cm.id} className="bg-fgx-blue/[.06] border-l-[3px] border-fgx-blue px-3.5 py-2.5 rounded-r-lg text-[13.5px]">
                            <div className="text-[11.5px] text-ink-3 mb-1"><b className="text-ink-2">{cm.autor_nome}</b> · {dataHoraBr(cm.criado_em)}</div>
                            {cm.texto}
                          </div>
                        ))}
                      </div>
                    )}

                    {comentandoBloco === b.id && (
                      <div className="mt-3 bg-fundo rounded-xl p-3.5">
                        <textarea autoFocus className="campo min-h-[80px]" value={rascunhoBloco}
                          onChange={(e) => setRascunhoBloco(e.target.value)}
                          placeholder="O que você quer apontar neste trecho?" />
                        <div className="flex gap-2 items-center mt-2.5">
                          <button className="btn-primario btn-p" disabled={salvando}
                            onClick={() => enviarComentario(b.id, rascunhoBloco)}>
                            {salvando ? "Enviando…" : "Enviar comentário"}
                          </button>
                          <button className="btn-contorno btn-p" onClick={() => setComentandoBloco(null)}>Cancelar</button>
                          <span className="ml-auto text-[11.5px] text-ink-3">como <b>{sessao?.pessoa_nome}</b></span>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {c.ajustes.length > 0 && (
              <Recolhivel titulo="Ajustes registrados" aberto>
                {c.ajustes.map((a) => (
                  <div key={a.id} className="border-l-[3px] border-fgx-orange bg-fgx-orange/[.06] px-4 py-3 rounded-r-lg mb-2.5 text-[13.5px]">
                    <div className="text-[11.5px] text-[#8A4A22] font-semibold mb-1">
                      {a.tipo === "estrutural" ? "Ajuste estrutural" : "Ajuste pontual"} · {a.status_avaliacao}
                    </div>
                    {a.descricao}
                  </div>
                ))}
              </Recolhivel>
            )}

            {c.trilha.length > 0 && (
              <Recolhivel titulo="Trilha de produção">
                <ol className="relative pl-7 before:absolute before:left-2.5 before:top-1.5 before:bottom-1.5 before:w-0.5 before:bg-linha list-none">
                  {c.trilha.map((e, i) => (
                    <li key={e.id} className="relative pb-4 last:pb-0">
                      <span className="absolute -left-7 top-0.5 w-[21px] h-[21px] rounded-full bg-fgx-beige-light text-[#8A4A22] font-titulo font-bold text-[11px] grid place-items-center">{i + 1}</span>
                      <div className="font-semibold text-sm">{e.passo}</div>
                      {e.descricao && <div className="text-[13.5px] text-ink-2 leading-snug">{e.descricao}</div>}
                    </li>
                  ))}
                </ol>
              </Recolhivel>
            )}

            {c.raciocinios.length > 0 && (
              <Recolhivel titulo="Raciocínios da produção">
                {c.raciocinios.map((r) => (
                  <details key={r.id} className="border border-linha rounded-xl mb-2.5 overflow-hidden">
                    <summary className="px-4 py-3 font-semibold text-sm cursor-pointer hover:bg-[#FBFAF9]">{r.titulo}</summary>
                    <div className="px-4 pb-3.5 text-[13.5px] text-ink-2 leading-relaxed whitespace-pre-wrap">{r.texto}</div>
                  </details>
                ))}
              </Recolhivel>
            )}

            {c.fontes.length > 0 && (
              <Recolhivel titulo="Fontes consultadas">
                <ul className="flex flex-col gap-2.5 list-none">
                  {c.fontes.map((f) => (
                    <li key={f.id} className="flex gap-3 items-baseline bg-fundo rounded-lg px-3.5 py-2.5 text-[13.5px]">
                      {f.tipo && <span className="text-[10px] font-bold uppercase tracking-wide text-ink-3 bg-white px-2 py-0.5 rounded whitespace-nowrap">{f.tipo}</span>}
                      {f.url
                        ? <a href={f.url} target="_blank" rel="noopener noreferrer">{f.titulo}</a>
                        : <span>{f.titulo}</span>}
                      {f.data_publicacao && <span className="ml-auto text-[11.5px] text-ink-3 whitespace-nowrap">{dataBr(f.data_publicacao)}</span>}
                    </li>
                  ))}
                </ul>
              </Recolhivel>
            )}

            <div className="px-7 py-5 border-t border-linha flex gap-3 flex-wrap items-center bg-[#FBFAF9] max-lg:px-5">
              {p.status === "aprovada" ? (
                <span className="text-fgx-green font-semibold text-sm">✓ Peça aprovada</span>
              ) : (
                <>
                  <button className="btn-verde" onClick={aprovar} disabled={salvando}>Aprovar peça</button>
                  <button className="btn-contorno" onClick={pedirAjuste} disabled={salvando}>Solicitar ajuste</button>
                  <span className="ml-auto text-xs text-ink-3">registrado como <b>{sessao?.pessoa_nome}</b></span>
                </>
              )}
            </div>
          </article>

          <nav className="flex justify-between gap-3 mt-4">
            <button className="btn-contorno btn-p" disabled={indice <= 0}
              onClick={() => navegar(`/c/${slug}/conteudos/${irmas[indice - 1].id}`)}>← Peça anterior</button>
            <button className="btn-contorno btn-p" disabled={indice < 0 || indice >= irmas.length - 1}
              onClick={() => navegar(`/c/${slug}/conteudos/${irmas[indice + 1].id}`)}>Próxima peça →</button>
          </nav>
        </div>

        {/* ---- histórico ---- */}
        <aside className="cartao sticky top-[88px] max-h-[calc(100vh-110px)] flex flex-col max-xl:static max-xl:max-h-none">
          <div className="px-5 py-4 border-b border-linha font-titulo font-bold text-[15px] flex items-center gap-2">
            Histórico de comentários
            <span className="ml-auto text-[11.5px] bg-fundo text-ink-3 px-2.5 py-0.5 rounded-full font-corpo">{c.comentarios.length}</span>
          </div>
          <div className="overflow-y-auto px-5 py-4 flex-1 flex flex-col gap-3">
            {c.comentarios.length === 0 ? (
              <p className="text-center text-ink-3 text-[13px] py-7 leading-relaxed">
                Nenhum comentário nesta peça ainda.<br /><br />
                Use o botão em cada {p.formato === "carrossel" ? "slide" : "trecho"} para apontar exatamente onde está a observação.
              </p>
            ) : c.comentarios.map((cm) => {
              const i = c.blocos.findIndex((b) => b.id === cm.peca_bloco_id);
              return (
                <div key={cm.id} className={`rounded-xl px-3.5 py-3 text-[13.5px] leading-snug ${cm.autor_tipo === "cliente" ? "bg-fgx-blue/[.07]" : "bg-fgx-orange/[.08]"}`}>
                  <div className="flex items-center gap-2 text-[11.5px] text-ink-3 mb-1.5 flex-wrap">
                    <b className="text-ink-2 text-xs">{cm.autor_nome}</b>
                    <span className="text-[10px] font-bold uppercase px-1.5 rounded bg-black/5">{cm.autor_tipo}</span>
                    <span>{dataHoraBr(cm.criado_em)}</span>
                  </div>
                  {cm.texto}
                  {i >= 0 && (
                    <button className="block w-full text-left text-[11.5px] text-fgx-blue underline mt-1.5"
                      onClick={() => document.getElementById(`bloco-${cm.peca_bloco_id}`)?.scrollIntoView({ block: "center", behavior: "smooth" })}>
                      ↳ {rotuloBloco(p, i, c.blocos.length, c.blocos[i].titulo)}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
          <div className="px-5 py-4 border-t border-linha">
            <label className="rotulo" htmlFor="geral">Comentar a peça inteira</label>
            <textarea id="geral" className="campo min-h-[72px]" value={rascunhoGeral}
              onChange={(e) => setRascunhoGeral(e.target.value)} placeholder="Observação geral sobre esta peça" />
            <button className="btn-primario btn-p w-full mt-2.5" disabled={salvando}
              onClick={() => enviarComentario(null, rascunhoGeral)}>
              Enviar como {sessao?.pessoa_nome}
            </button>
          </div>
        </aside>
      </div>

      <Link to={`/c/${slug}/conteudos`} className="inline-block mt-6 text-sm">← Voltar ao Painel de Conteúdos</Link>
    </>
  );
}
