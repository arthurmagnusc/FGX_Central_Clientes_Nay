import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ciclos, entregaveis, pecasDoCiclo, relatorios } from "../../lib/api";
import { dataBr, mesBr } from "../../lib/formato";
import { Carregando, ErroNaTela } from "../../componentes/Basicos";
import type { Entregavel, Peca, Relatorio } from "../../lib/tipos";

export default function VisaoGeral() {
  const { slug = "" } = useParams();
  const [ents, setEnts] = useState<Entregavel[]>([]);
  const [rels, setRels] = useState<Relatorio[]>([]);
  const [pecas, setPecas] = useState<Peca[]>([]);
  const [mes, setMes] = useState("");
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState("");

  async function carregar() {
    setCarregando(true); setErro("");
    try {
      const [e, r, cs] = await Promise.all([entregaveis(), relatorios(), ciclos()]);
      setEnts(e); setRels(r);
      if (cs[0]) { setMes(cs[0].mes_referencia); setPecas(await pecasDoCiclo(cs[0].id)); }
    } catch (err) { setErro((err as Error).message); }
    finally { setCarregando(false); }
  }
  useEffect(() => { carregar(); }, []);

  if (carregando) return <Carregando o="a visão geral" />;
  if (erro) return <ErroNaTela erro={erro} aoTentar={carregar} />;

  const aguardando = pecas.filter((p) => p.status !== "aprovada").length;
  const ultimo = rels[0];
  // Os KPIs do relatório mais recente são a fonte do percentual: o portal não
  // recalcula escopo, ele mostra o que a FGX apurou e assinou no relatório.
  const kpiPrincipal = ultimo?.kpis?.[0];

  return (
    <>
      <div className="flex gap-8 items-start flex-wrap mb-8">
        <header className="flex-1 min-w-[320px]">
          <div className="text-[11.5px] font-bold tracking-[1.4px] uppercase text-fgx-red mb-3.5">
            Contrato de recorrência
          </div>
          <h1 className="text-[44px] max-lg:text-[30px] font-bold leading-[1.08] tracking-tight mb-4">
            Clareza para decidir.<br />Material para avançar.
          </h1>
          <p className="text-base text-ink-2 max-w-[600px]">
            Tudo o que foi contratado e tudo o que foi entregue, lado a lado — com os documentos do projeto,
            os relatórios do período e os conteúdos em validação em um só lugar.
          </p>
        </header>

        {kpiPrincipal && (
          <div className="cartao shadow-alto p-6 w-[340px] max-lg:w-full">
            <div className="flex items-baseline justify-between mb-3">
              <span className="text-[13.5px] text-ink-2 font-medium">{kpiPrincipal.rotulo}</span>
              <span className="font-titulo text-[29px] font-bold text-fgx-red leading-none">{kpiPrincipal.valor}</span>
            </div>
            <div className="h-[7px] rounded-md bg-fundo overflow-hidden">
              <div className="h-full rounded-md bg-[linear-gradient(90deg,#B12119,#E77938)]"
                style={{ width: barraDoKpi(kpiPrincipal.valor) }} />
            </div>
            <div className="flex justify-between gap-3 mt-3 text-xs text-ink-3">
              <span>{ultimo.titulo}</span>
              <span>{dataBr(ultimo.emitido_em)}</span>
            </div>
          </div>
        )}
      </div>

      <div className="flex flex-wrap border-y border-linha mb-10">
        <Indicador valor={String(ents.length)} rotulo="Entregas disponíveis" />
        <Indicador valor={String(pecas.length)} rotulo={`Peças no ciclo${mes ? ` de ${mesBr(mes)}` : ""}`} />
        <Indicador valor={String(rels.length)} rotulo="Relatórios emitidos" />
      </div>

      <div className="flex items-center gap-4 mb-6 flex-wrap">
        <div className="w-[50px] h-[50px] rounded-full bg-fgx-red text-white grid place-items-center font-titulo font-bold text-[15px]">01</div>
        <div>
          <h2 className="text-[25px] font-bold tracking-tight leading-tight">Onde continuar</h2>
          <div className="text-[13.5px] text-ink-3 mt-0.5">Os três atalhos mais usados neste contrato.</div>
        </div>
      </div>

      <div className="grid grid-cols-[repeat(auto-fill,minmax(320px,1fr))] gap-4">
        <Atalho para={`/c/${slug}/conteudos`} categoria="Painel de Conteúdos"
          titulo={aguardando ? `${aguardando} ${aguardando === 1 ? "peça aguardando" : "peças aguardando"} sua validação` : "Tudo validado neste ciclo"}
          descricao="Leia, comente trecho a trecho e aprove o conteúdo do ciclo."
          acao="Abrir painel" />
        <Atalho para={`/c/${slug}/relatorios`} categoria="Relatórios"
          titulo={ultimo?.titulo ?? "Nenhum relatório ainda"}
          descricao="Volume previsto, publicado e produzido em cada frente do contrato."
          acao="Ver relatórios" />
        <Atalho para={`/c/${slug}/entregas`} categoria="Entregas"
          titulo={`${ents.length} ${ents.length === 1 ? "documento" : "documentos"} do contrato`}
          descricao="Diagnóstico, planejamento, apresentações, propostas e políticas."
          acao="Ver entregas" />
      </div>
    </>
  );
}

function barraDoKpi(valor: string) {
  const n = Number(valor.replace(/[^\d]/g, ""));
  if (!n) return "100%";
  return `${Math.min(100, n)}%`;
}

function Indicador({ valor, rotulo }: { valor: string; rotulo: string }) {
  return (
    <div className="flex-1 min-w-[200px] flex items-center gap-3.5 px-6 py-5 border-r border-linha last:border-r-0 max-lg:border-r-0 max-lg:border-b">
      <div>
        <div className="font-titulo text-[22px] font-bold leading-none">{valor}</div>
        <div className="text-[10.5px] tracking-wide uppercase text-ink-3 mt-1">{rotulo}</div>
      </div>
    </div>
  );
}

function Atalho(
  { para, categoria, titulo, descricao, acao }:
  { para: string; categoria: string; titulo: string; descricao: string; acao: string },
) {
  return (
    <Link to={para} className="cartao p-5 flex flex-col hover:border-fgx-orange transition">
      <div className="text-[10.5px] font-bold tracking-wider uppercase text-ink-3 mb-1.5">{categoria}</div>
      <h3 className="text-[16.5px] font-bold leading-snug">{titulo}</h3>
      <p className="text-[13.5px] text-ink-2 mt-2 leading-snug">{descricao}</p>
      <div className="border-t border-linha pt-3.5 mt-auto pt-4 text-fgx-red font-semibold text-[13px]">{acao} →</div>
    </Link>
  );
}
