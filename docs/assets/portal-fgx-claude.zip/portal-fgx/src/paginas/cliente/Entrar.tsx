import { useState, type FormEvent } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { entrar } from "../../lib/api";

/**
 * Uma senha por escritório, mais o nome de quem está entrando.
 * O nome não é verificado — serve para o histórico não ficar anônimo, não
 * como prova de autoria. Está escrito na tela para ninguém se enganar.
 */
export default function Entrar() {
  const { slug = "" } = useParams();
  const navegar = useNavigate();
  const [senha, setSenha] = useState("");
  const [nome, setNome] = useState("");
  const [erro, setErro] = useState("");
  const [enviando, setEnviando] = useState(false);

  async function enviar(e: FormEvent) {
    e.preventDefault();
    setErro("");
    if (nome.trim().length < 2) return setErro("Informe seu nome para entrar.");
    setEnviando(true);
    try {
      await entrar(slug, senha, nome.trim());
      navegar(`/c/${slug}/visao-geral`, { replace: true });
    } catch (err) {
      setErro((err as Error).message);
    } finally {
      setEnviando(false);
    }
  }

  return (
    <div className="min-h-screen grid place-items-center p-6
      bg-[radial-gradient(900px_520px_at_12%_-10%,rgba(231,121,56,.32),transparent_60%),linear-gradient(150deg,#7E131C_0%,#B12119_55%,#C4331F_100%)]">
      <div className="bg-white rounded-2xl p-9 w-full max-w-[430px] shadow-2xl">
        <div className="w-13 h-13 w-[52px] h-[52px] rounded-xl grid place-items-center font-titulo font-black text-white text-[17px] mb-5
          bg-[linear-gradient(140deg,#B12119,#E77938)]">FGX</div>
        <h1 className="text-[26px] font-bold tracking-tight">Portal do Cliente</h1>
        <p className="text-ink-3 text-sm mt-1.5 mb-7">Entre com a senha do escritório.</p>

        {erro && <div className="bg-fgx-red/[.08] text-fgx-red text-[13px] px-3.5 py-2.5 rounded-lg mb-4">{erro}</div>}

        <form onSubmit={enviar} noValidate>
          <div className="mb-4">
            <label className="rotulo" htmlFor="senha">Senha de acesso</label>
            <input id="senha" type="password" className="campo" autoComplete="current-password"
              value={senha} onChange={(e) => setSenha(e.target.value)} />
          </div>
          <div className="mb-4">
            <label className="rotulo" htmlFor="nome">Seu nome</label>
            <input id="nome" className="campo" autoComplete="name"
              value={nome} onChange={(e) => setNome(e.target.value)} />
            <p className="text-xs text-ink-3 mt-1.5 leading-snug">
              Usamos seu nome para identificar automaticamente cada comentário e cada aprovação.
              Você não precisa digitar de novo a cada ação.
            </p>
          </div>
          <button className="btn-primario w-full" disabled={enviando}>
            {enviando ? "Entrando…" : "Entrar"}
          </button>
        </form>
      </div>
    </div>
  );
}
