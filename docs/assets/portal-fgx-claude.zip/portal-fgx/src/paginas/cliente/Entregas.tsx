import { useEffect, useMemo, useState } from "react";
import { baixarEntregavel, entregaveis } from "../../lib/api";
import { dataBr, NOME_CATEGORIA, ORDEM_CATEGORIAS, tamanhoArquivo } from "../../lib/formato";
import { Aviso, Carregando, ErroNaTela, Vazio } from "../../componentes/Basicos";
import type { CategoriaEntregavel, Entregavel } from "../../lib/tipos";

export default function Entregas() {
  const [itens, setItens] = useState<Entregavel[]>([]);
  const [busca, setBusca] = useState("");
  const [categoria, setCategoria] = useState<CategoriaEntregavel | "todas">("todas");
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState("");
  const [aviso, setAviso] = useState<{ texto: string; tipo: "ok" | "erro" } | null>(null);

  async function carregar() {
    setCarregando(true); setErro("");
    try { setItens(await entregaveis()); }
    catch (e) { setErro((e as Error).message); }
    finally { setCarregando(false); }
  }
  useEffect(() => { carregar(); }, []);

  const porCategoria = useMemo(() => {
    const m = new Map<CategoriaEntregavel, Entregavel[]>();
    itens.forEach((i) => m.set(i.categoria, [...(m.get(i.categoria) ?? []), i]));
    return m;
  }, [itens]);

  const q = busca.trim().toLowerCase();
  const filtrados = itens.filter((i) =>
    (categoria === "todas" || i.categoria === categoria) &&
    (!q || `${i.titulo} ${i.descricao ?? ""}`.toLowerCase().includes(q)));

  async function baixar(item: Entregavel) {
    try {
      await baixarEntregavel(item.id);
      setAviso({ texto: `Baixando ${item.nome_arquivo}`, tipo: "ok" });
    } catch (e) { setAviso({ texto: (e as Error).message, tipo: "erro" }); }
  }

  if (carregando) return <Carregando o="as entregas" />;
  if (erro) return <ErroNaTela erro={erro} aoTentar={carregar} />;

  return (
    <>
      {aviso && <Aviso texto={aviso.texto} tipo={aviso.tipo} aoFechar={() => setAviso(null)} />}

      <header className="mb-8">
        <div className="text-[11.5px] font-bold tracking-[1.4px] uppercase text-fgx-red mb-3.5">Documentos do contrato</div>
        <h1 className="text-[44px] max-lg:text-[30px] font-bold leading-[1.08] tracking-tight mb-4">Entregas do projeto</h1>
        <p className="text-base text-ink-2 max-w-[600px]">
          Os materiais estruturantes do contrato, organizados por frente. Cada documento fica disponível na
          versão mais recente, com o histórico das anteriores.
        </p>
      </header>

      <div className="flex items-center gap-4 mb-5 flex-wrap">
        <div className="w-[50px] h-[50px] rounded-full bg-fgx-red text-white grid place-items-center font-titulo font-bold text-[15px]">01</div>
        <div>
          <h2 className="text-[25px] font-bold tracking-tight leading-tight">Entregas do projeto</h2>
          <div className="text-[13.5px] text-ink-3 mt-0.5">Documentos mais recentes e materiais consolidados.</div>
        </div>
        <div className="ml-auto max-lg:w-full">
          <input className="campo w-[280px] max-lg:w-full" placeholder="Buscar documento"
            value={busca} onChange={(e) => setBusca(e.target.value)} aria-label="Buscar documento" />
        </div>
      </div>

      <div className="flex gap-2 flex-wrap mb-5">
        <Chip on={categoria === "todas"} onClick={() => setCategoria("todas")}>Todos <b>{itens.length}</b></Chip>
        {ORDEM_CATEGORIAS.filter((c) => porCategoria.get(c)?.length).map((c) => (
          <Chip key={c} on={categoria === c} onClick={() => setCategoria(c)}>
            {NOME_CATEGORIA[c]} <b>{porCategoria.get(c)!.length}</b>
          </Chip>
        ))}
      </div>

      {filtrados.length === 0 ? (
        <Vazio>Nenhum documento neste filtro.</Vazio>
      ) : (
        <div className="grid grid-cols-[repeat(auto-fill,minmax(320px,1fr))] gap-4">
          {filtrados.map((i) => (
            <article key={i.id} className="cartao p-5 flex flex-col">
              <div className="text-[10.5px] font-bold tracking-wider uppercase text-ink-3 mb-1.5">
                {NOME_CATEGORIA[i.categoria]}
              </div>
              <h3 className="text-[16.5px] font-bold leading-snug mb-2">{i.titulo}</h3>
              {i.descricao && <p className="text-[13.5px] text-ink-2 leading-snug mb-4">{i.descricao}</p>}
              <div className="flex items-center gap-3 text-xs text-ink-3 border-t border-linha pt-3.5 mt-auto flex-wrap">
                <span>{dataBr(i.publicado_em)}</span>
                <span>·</span><span>{tamanhoArquivo(i.tamanho_bytes)}</span>
                <span>·</span><span>v{i.versao}</span>
                <button className="btn-primario btn-p ml-auto" onClick={() => baixar(i)}>Baixar</button>
              </div>
            </article>
          ))}
        </div>
      )}
    </>
  );
}

function Chip({ on, onClick, children }: { on: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick}
      className={`flex items-center gap-2 px-4 py-2 border rounded-full text-[13px] font-semibold transition
        ${on ? "border-fgx-red text-fgx-red bg-fgx-red/5" : "border-linha bg-white text-ink-2 hover:border-ink-3"}`}>
      {children}
    </button>
  );
}
