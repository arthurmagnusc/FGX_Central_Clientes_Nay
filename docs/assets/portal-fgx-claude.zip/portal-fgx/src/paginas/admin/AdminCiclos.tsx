import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ciclosDoCliente, clientes, pecasDoCicloAdmin, publicarCiclo } from "../../lib/apiAdmin";
import { mesBr, NOME_FORMATO, numeroBr } from "../../lib/formato";
import { Aviso, Carregando, ErroNaTela, Pilula, Vazio } from "../../componentes/Basicos";
import type { Ciclo, Cliente, Peca } from "../../lib/tipos";

export default function AdminCiclos() {
  const [lista, setLista] = useState<Cliente[]>([]);
  const [clienteId, setClienteId] = useState("");
  const [cs, setCs] = useState<Ciclo[]>([]);
  const [cicloId, setCicloId] = useState("");
  const [pecas, setPecas] = useState<Peca[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState("");
  const [aviso, setAviso] = useState<{ texto: string; tipo: "ok" | "erro" } | null>(null);

  useEffect(() => { (async () => {
    try { const c = await clientes(); setLista(c); setClienteId(c[0]?.id ?? ""); }
    catch (e) { setErro((e as Error).message); } finally { setCarregando(false); }
  })(); }, []);

  useEffect(() => { if (!clienteId) return; (async () => {
    const c = await ciclosDoCliente(clienteId);
    setCs(c); setCicloId(c[0]?.id ?? "");
  })(); }, [clienteId]);

  useEffect(() => { if (!cicloId) { setPecas([]); return; }
    pecasDoCicloAdmin(cicloId).then(setPecas).catch((e) => setErro(e.message));
  }, [cicloId]);

  async function alternarPublicacao() {
    const ciclo = cs.find((c) => c.id === cicloId);
    if (!ciclo) return;
    const publicar = ciclo.status !== "publicado";
    if (publicar && !confirm("Publicar o ciclo torna todas as peças visíveis ao cliente. Continuar?")) return;
    try {
      await publicarCiclo(cicloId, publicar);
      setCs(await ciclosDoCliente(clienteId));
      setAviso({ texto: publicar ? "Ciclo publicado" : "Ciclo voltou a rascunho", tipo: "ok" });
    } catch (e) { setAviso({ texto: (e as Error).message, tipo: "erro" }); }
  }

  if (carregando) return <Carregando o="os ciclos" />;
  if (erro) return <ErroNaTela erro={erro} />;

  const ciclo = cs.find((c) => c.id === cicloId);

  return (
    <>
      {aviso && <Aviso texto={aviso.texto} tipo={aviso.tipo} aoFechar={() => setAviso(null)} />}

      <div className="flex items-start gap-4 mb-7 flex-wrap">
        <div>
          <h1 className="text-[29px] font-bold tracking-tight leading-tight">Ciclos e peças</h1>
          <p className="text-sm text-ink-3 mt-1.5 max-w-[620px]">
            Enquanto o ciclo está em rascunho, o cliente não vê nada. Publique só quando o conteúdo estiver pronto para validação.
          </p>
        </div>
        <div className="ml-auto flex gap-2.5 flex-wrap items-end">
          <div>
            <label className="rotulo" htmlFor="cli">Cliente</label>
            <select id="cli" className="campo py-2" value={clienteId} onChange={(e) => setClienteId(e.target.value)}>
              {lista.map((c) => <option key={c.id} value={c.id}>{c.nome}</option>)}
            </select>
          </div>
          {cs.length > 0 && (
            <div>
              <label className="rotulo" htmlFor="cic">Ciclo</label>
              <select id="cic" className="campo py-2" value={cicloId} onChange={(e) => setCicloId(e.target.value)}>
                {cs.map((c) => <option key={c.id} value={c.id}>{mesBr(c.mes_referencia)}</option>)}
              </select>
            </div>
          )}
          {ciclo && (
            <button className={ciclo.status === "publicado" ? "btn-contorno" : "btn-primario"} onClick={alternarPublicacao}>
              {ciclo.status === "publicado" ? "Voltar a rascunho" : "Publicar ciclo"}
            </button>
          )}
          {cicloId && <Link className="btn-escuro" to={`/admin/pecas/nova?ciclo=${cicloId}`}>+ Nova peça</Link>}
        </div>
      </div>

      {!ciclo ? <Vazio>Este cliente ainda não tem ciclo.<br />Crie o primeiro para começar a cadastrar peças.</Vazio> : (
        <>
          <div className="flex items-center gap-3 mb-4">
            <Pilula status={ciclo.status === "publicado" ? "aprovada" : "pendente"} />
            <h2 className="text-[20px] font-bold capitalize">{mesBr(ciclo.mes_referencia)}</h2>
            <span className="text-sm text-ink-3">{pecas.length} peças</span>
          </div>

          {pecas.length === 0 ? <Vazio>Nenhuma peça neste ciclo ainda.</Vazio> : (
            <div className="cartao overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="text-left text-[10.5px] tracking-wide uppercase text-ink-3">
                    <th className="px-4 pt-4 pb-3 border-b border-linha w-[38%]">Peça</th>
                    <th className="px-4 pt-4 pb-3 border-b border-linha">Canal e formato</th>
                    <th className="px-4 pt-4 pb-3 border-b border-linha">Editoria</th>
                    <th className="px-4 pt-4 pb-3 border-b border-linha">Blocos</th>
                    <th className="px-4 pt-4 pb-3 border-b border-linha">Comentários</th>
                    <th className="px-4 pt-4 pb-3 border-b border-linha">Status</th>
                    <th className="px-4 pt-4 pb-3 border-b border-linha" />
                  </tr>
                </thead>
                <tbody>
                  {pecas.map((p) => (
                    <tr key={p.id} className="hover:bg-[#FBFAF9]">
                      <td className="px-4 py-3.5 border-b border-linha">
                        <div className="font-semibold leading-snug">{p.tema}</div>
                        <div className="text-xs text-ink-3 mt-0.5">{p.area_direito} {p.funil && `· Funil ${p.funil}`}</div>
                      </td>
                      <td className="px-4 py-3.5 border-b border-linha text-[13px]">
                        <span className="etiqueta">{p.canal_nome}</span>{" "}
                        <span className="etiqueta-n">{NOME_FORMATO[p.formato]}</span>
                      </td>
                      <td className="px-4 py-3.5 border-b border-linha text-[13px]">{p.editoria_nome ?? "—"}</td>
                      <td className="px-4 py-3.5 border-b border-linha text-[13px]">{numeroBr(Number(p.total_blocos))}</td>
                      <td className="px-4 py-3.5 border-b border-linha text-[13px]">{numeroBr(Number(p.total_comentarios))}</td>
                      <td className="px-4 py-3.5 border-b border-linha"><Pilula status={p.status} /></td>
                      <td className="px-4 py-3.5 border-b border-linha text-right">
                        <Link className="text-fgx-red font-semibold text-[13px]" to={`/admin/pecas/${p.id}`}>Editar →</Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </>
  );
}
