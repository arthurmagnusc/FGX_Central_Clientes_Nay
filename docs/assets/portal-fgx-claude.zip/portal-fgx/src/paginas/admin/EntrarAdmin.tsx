import { useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { entrarAdmin } from "../../lib/api";

export default function EntrarAdmin() {
  const navegar = useNavigate();
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");
  const [enviando, setEnviando] = useState(false);

  async function enviar(e: FormEvent) {
    e.preventDefault(); setErro(""); setEnviando(true);
    try { await entrarAdmin(senha); navegar("/admin/ciclos", { replace: true }); }
    catch (err) { setErro((err as Error).message); }
    finally { setEnviando(false); }
  }

  return (
    <div className="min-h-screen grid place-items-center p-6 bg-[linear-gradient(160deg,#26221F_0%,#151312_60%,#0C0B0A_100%)]">
      <div className="bg-white rounded-2xl p-9 w-full max-w-[420px] shadow-2xl">
        <div className="w-[52px] h-[52px] rounded-xl grid place-items-center font-titulo font-black text-white text-[17px] mb-5
          bg-[linear-gradient(140deg,#B12119,#E77938)]">FGX</div>
        <h1 className="text-[25px] font-bold tracking-tight">Painel administrativo</h1>
        <p className="text-ink-3 text-sm mt-1.5 mb-6">Área interna da equipe FGX.</p>
        {erro && <div className="bg-fgx-red/[.08] text-fgx-red text-[13px] px-3.5 py-2.5 rounded-lg mb-4">{erro}</div>}
        <form onSubmit={enviar}>
          <div className="mb-4">
            <label className="rotulo" htmlFor="s">Senha de administrador</label>
            <input id="s" type="password" className="campo" value={senha}
              onChange={(e) => setSenha(e.target.value)} autoComplete="current-password" />
          </div>
          <button className="btn-escuro w-full" disabled={enviando}>{enviando ? "Entrando…" : "Entrar"}</button>
        </form>
      </div>
    </div>
  );
}
