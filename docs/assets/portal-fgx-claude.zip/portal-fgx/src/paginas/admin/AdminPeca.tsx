import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import {
  canaisDoCliente, carregarPecaParaEdicao, ciclosDoCliente, clientes,
  editoriasDoCliente, pilaresDoCliente, salvarPeca, type RascunhoPeca,
} from "../../lib/apiAdmin";
import { dividirEmBlocos, juntarComAnterior, mover, separarBloco, totalCaracteres, type BlocoRascunho, type ModoDivisao } from "../../lib/blocos";
import { LIMITE_SLIDE, NOME_FORMATO, numeroBr } from "../../lib/formato";
import { Aviso, Carregando } from "../../componentes/Basicos";

const TIPOS_FONTE = ["Legislação", "Jurisprudência", "Norma regulatória", "Órgão regulador", "Imprensa", "Doutrina", "Ranking", "Dado setorial", "Outro"];

/** Trilha padrão da FGX — carregar e ajustar é muito mais rápido que digitar nove vezes. */
const TRILHA_PADRAO = [
  { passo: "Scan setorial mensal", descricao: "Varredura de 30 a 45 dias em atos normativos, jurisprudência e imprensa do setor." },
  { passo: "Seleção da ancoragem", descricao: "Escolha do gancho e classificação como jornalístico ou analítico." },
  { passo: "Checagem da trava de confidencialidade", descricao: "Confirmação de que o tema não toca caso ativo identificável de cliente." },
  { passo: "Geração de ângulos", descricao: "Ângulos gerados a partir da ancoragem, com registro dos descartados." },
  { passo: "Curadoria estratégica", descricao: "Escolha do ângulo que fala com a persona-alvo da peça." },
  { passo: "Aprofundamento factual", descricao: "Verificação dos dispositivos e fontes citados." },
  { passo: "Redação no formato do canal", descricao: "Texto produzido no padrão do formato e do funil." },
  { passo: "Revisão de tom", descricao: "Ajuste ao tom de voz das diretrizes do cliente." },
  { passo: "Revisão técnica interna", descricao: "Conferência de precisão antes do envio para validação." },
];

type Aba = "conteudo" | "gancho" | "trilha" | "raciocinios" | "fontes";

export default function AdminPeca() {
  const { pecaId } = useParams();
  const [params] = useSearchParams();
  const navegar = useNavigate();
  const nova = !pecaId || pecaId === "nova";

  const [aba, setAba] = useState<Aba>("conteudo");
  const [carregando, setCarregando] = useState(true);
  const [aviso, setAviso] = useState<{ texto: string; tipo: "ok" | "erro" } | null>(null);
  const [salvando, setSalvando] = useState(false);

  const [, setClienteId] = useState("");
  const [canais, setCanais] = useState<{ codigo: string; nome: string; limite_caracteres_padrao: number | null }[]>([]);
  const [editorias, setEditorias] = useState<{ id: string; nome: string }[]>([]);
  const [pilares, setPilares] = useState<{ id: string; nome: string }[]>([]);

  const [r, setR] = useState<RascunhoPeca>({
    ciclo_id: params.get("ciclo") ?? "", tema: "", area_direito: "", canal_codigo: "",
    formato: "carrossel", editoria_id: null, pilar_id: null, funil: "topo",
    gancho_texto: "", gancho_tipo: "jornalistico", gancho_url: "", gancho_data: null,
  });
  const [blocos, setBlocos] = useState<BlocoRascunho[]>([]);
  const [trilha, setTrilha] = useState<{ passo: string; descricao: string }[]>([]);
  const [raciocinios, setRaciocinios] = useState<{ titulo: string; texto: string }[]>([]);
  const [fontes, setFontes] = useState<{ titulo: string; url: string; tipo: string; data_publicacao: string | null }[]>([]);

  const [colado, setColado] = useState("");
  const [modo, setModo] = useState<ModoDivisao>("paragrafo");

  useEffect(() => { (async () => {
    try {
      const cs = await clientes();
      let cid = cs[0]?.id ?? "";
      let rascunho = r;

      if (!nova) {
        const dados = await carregarPecaParaEdicao(pecaId!);
        const p: any = dados.peca;
        const ciclos = await Promise.all(cs.map(async (c) => ({ c, lista: await ciclosDoCliente(c.id) })));
        cid = ciclos.find((x) => x.lista.some((l) => l.id === p.ciclo_id))?.c.id ?? cid;
        rascunho = {
          id: p.id, ciclo_id: p.ciclo_id, tema: p.tema, area_direito: p.area_direito ?? "",
          canal_codigo: p.canal_codigo, formato: p.formato, editoria_id: p.editoria_id,
          pilar_id: p.pilar_id, funil: p.funil,
          gancho_texto: p.gancho_texto ?? "", gancho_tipo: p.gancho_tipo ?? "jornalistico",
          gancho_url: p.gancho_url ?? "", gancho_data: p.gancho_data,
        };
        setR(rascunho);
        setBlocos(dados.blocos); setTrilha(dados.trilha);
        setRaciocinios(dados.raciocinios); setFontes(dados.fontes);
      }

      setClienteId(cid);
      const [cn, ed, pl] = await Promise.all([canaisDoCliente(cid), editoriasDoCliente(cid), pilaresDoCliente(cid)]);
      setCanais(cn); setEditorias(ed as any); setPilares(pl as any);
      if (nova && cn[0]) setR((x) => ({ ...x, canal_codigo: cn[0].codigo }));
    } catch (e) { setAviso({ texto: (e as Error).message, tipo: "erro" }); }
    finally { setCarregando(false); }
  })(); /* eslint-disable-next-line */ }, [pecaId]);

  const carrossel = r.formato === "carrossel";
  const limiteCanal = canais.find((c) => c.codigo === r.canal_codigo)?.limite_caracteres_padrao ?? null;
  const total = useMemo(() => totalCaracteres(blocos), [blocos]);
  const acimaDoSlide = blocos.filter((b) => carrossel && b.conteudo.length > LIMITE_SLIDE).length;

  function dividir(acrescentar = false) {
    const novos = dividirEmBlocos(colado, modo);
    if (!novos.length) return setAviso({ texto: "Cole um texto antes de dividir.", tipo: "erro" });
    if (!acrescentar && blocos.length && !confirm(`Isso substitui os ${blocos.length} blocos atuais. Continuar?`)) return;
    setBlocos(acrescentar ? [...blocos, ...novos] : novos);
    setAviso({ texto: `${novos.length} blocos ${acrescentar ? "acrescentados" : "criados"}`, tipo: "ok" });
  }

  async function salvar() {
    if (!r.tema.trim()) return setAviso({ texto: "Dê um tema à peça antes de salvar.", tipo: "erro" });
    if (!blocos.length) return setAviso({ texto: "A peça precisa de pelo menos um bloco.", tipo: "erro" });
    const falta = [
      !r.gancho_texto && "gancho", !trilha.length && "trilha",
      !raciocinios.length && "raciocínios", fontes.length < 3 && "fontes (mínimo 3)",
    ].filter(Boolean);
    if (falta.length && !confirm(
      `A peça será salva, mas está sem: ${falta.join(", ")}.\n\nEssas camadas são o que o cliente vê como prova de processo. Salvar assim mesmo?`)) return;

    setSalvando(true);
    try {
      const id = await salvarPeca(r, blocos, trilha, raciocinios, fontes);
      setAviso({ texto: falta.length ? "Peça salva com pendências" : "Peça salva", tipo: "ok" });
      if (nova) navegar(`/admin/pecas/${id}`, { replace: true });
    } catch (e) { setAviso({ texto: (e as Error).message, tipo: "erro" }); }
    finally { setSalvando(false); }
  }

  if (carregando) return <Carregando o="a peça" />;

  const abas: { id: Aba; nome: string; n: number }[] = [
    { id: "conteudo", nome: "Conteúdo e blocos", n: blocos.length },
    { id: "gancho", nome: "Gancho e ancoragem", n: r.gancho_texto ? 1 : 0 },
    { id: "trilha", nome: "Trilha de produção", n: trilha.length },
    { id: "raciocinios", nome: "Raciocínios", n: raciocinios.length },
    { id: "fontes", nome: "Fontes", n: fontes.length },
  ];

  return (
    <>
      {aviso && <Aviso texto={aviso.texto} tipo={aviso.tipo} aoFechar={() => setAviso(null)} />}

      <div className="flex items-start gap-4 mb-6 flex-wrap">
        <div>
          <h1 className="text-[29px] font-bold tracking-tight">{nova ? "Nova peça" : "Editar peça"}</h1>
          <p className="text-sm text-ink-3 mt-1.5 max-w-[620px]">
            Cole o texto vindo da produção e divida em blocos. Cada bloco é o que o cliente vai poder comentar
            isoladamente — slide no carrossel, trecho no artigo.
          </p>
        </div>
        <div className="ml-auto flex gap-2.5">
          <button className="btn-contorno" onClick={() => navegar("/admin/ciclos")}>Voltar</button>
          <button className="btn-primario" onClick={salvar} disabled={salvando}>{salvando ? "Salvando…" : "Salvar peça"}</button>
        </div>
      </div>

      <div className="cartao p-5 mb-5">
        <div className="mb-4">
          <label className="rotulo" htmlFor="tema">Tema da peça</label>
          <input id="tema" className="campo" value={r.tema} onChange={(e) => setR({ ...r, tema: e.target.value })} />
        </div>
        <div className="grid grid-cols-[repeat(auto-fit,minmax(180px,1fr))] gap-4">
          <Campo rotulo="Canal">
            <select className="campo" value={r.canal_codigo} onChange={(e) => setR({ ...r, canal_codigo: e.target.value })}>
              {canais.map((c) => <option key={c.codigo} value={c.codigo}>{c.nome}</option>)}
            </select>
          </Campo>
          <Campo rotulo="Formato">
            <select className="campo" value={r.formato} onChange={(e) => setR({ ...r, formato: e.target.value })}>
              {Object.entries(NOME_FORMATO).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </Campo>
          <Campo rotulo="Editoria">
            <select className="campo" value={r.editoria_id ?? ""} onChange={(e) => setR({ ...r, editoria_id: e.target.value || null })}>
              <option value="">—</option>
              {editorias.map((e2) => <option key={e2.id} value={e2.id}>{e2.nome}</option>)}
            </select>
          </Campo>
          <Campo rotulo="Pilar">
            <select className="campo" value={r.pilar_id ?? ""} onChange={(e) => setR({ ...r, pilar_id: e.target.value || null })}>
              <option value="">—</option>
              {pilares.map((p) => <option key={p.id} value={p.id}>{p.nome}</option>)}
            </select>
          </Campo>
          <Campo rotulo="Funil">
            <select className="campo" value={r.funil ?? ""} onChange={(e) => setR({ ...r, funil: e.target.value || null })}>
              <option value="topo">Topo</option><option value="meio">Meio</option><option value="fundo">Fundo</option>
            </select>
          </Campo>
          <Campo rotulo="Área do Direito">
            <input className="campo" value={r.area_direito} onChange={(e) => setR({ ...r, area_direito: e.target.value })} />
          </Campo>
        </div>
      </div>

      <div className="flex gap-1 bg-fundo rounded-xl p-1 w-fit max-w-full flex-wrap mb-5">
        {abas.map((a) => (
          <button key={a.id} onClick={() => setAba(a.id)}
            className={`px-3.5 py-2 rounded-lg text-[12.5px] font-semibold transition
              ${aba === a.id ? "bg-white text-fgx-red shadow-sm" : "text-ink-3 hover:text-ink"}`}>
            {a.nome} {a.n > 0 && <span className="opacity-55">{a.n}</span>}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-[1fr_330px] max-xl:grid-cols-1 gap-5 items-start">
        <div>
          {aba === "conteudo" && (
            <>
              <div className="border-2 border-dashed border-linha rounded-xl p-5 bg-white mb-5">
                <label className="rotulo" htmlFor="colar">Colar o texto integral</label>
                <textarea id="colar" className="w-full min-h-[190px] border-0 outline-none resize-y text-[14.5px] leading-relaxed"
                  placeholder="Cole aqui o texto da peça, do jeito que veio da produção."
                  value={colado} onChange={(e) => setColado(e.target.value)} />
                <div className="flex gap-2.5 items-center flex-wrap mt-3.5 pt-3.5 border-t border-linha">
                  <div className="flex bg-fundo rounded-lg p-0.5 gap-0.5">
                    {(["paragrafo", "titulo", "separador"] as ModoDivisao[]).map((m) => (
                      <button key={m} onClick={() => setModo(m)}
                        className={`px-3 py-1.5 rounded-md text-[12.5px] font-semibold ${modo === m ? "bg-white text-fgx-red shadow-sm" : "text-ink-3"}`}>
                        {m === "paragrafo" ? "Por parágrafo" : m === "titulo" ? "Por título (##)" : "Por separador (---)"}
                      </button>
                    ))}
                  </div>
                  <button className="btn-escuro btn-p" onClick={() => dividir(false)}>Dividir em blocos</button>
                  <button className="btn-contorno btn-p" onClick={() => dividir(true)}>Acrescentar ao final</button>
                </div>
              </div>

              <div className="flex items-center gap-3 mb-3 flex-wrap">
                <h3 className="text-[18px] font-bold">Blocos da peça</h3>
                <span className="text-[12.5px] text-ink-3">
                  {blocos.length} {blocos.length === 1 ? "bloco" : "blocos"}
                  {carrossel && ` · limite de ${LIMITE_SLIDE} caracteres por slide`}
                </span>
                <button className="btn-contorno btn-p ml-auto" onClick={() => setBlocos([...blocos, { titulo: "", conteudo: "" }])}>
                  + Bloco em branco
                </button>
              </div>

              {blocos.length === 0 ? (
                <div className="cartao p-10 text-center text-ink-3 text-sm">
                  Nenhum bloco ainda. Cole o texto acima e clique em <b>Dividir em blocos</b>.
                </div>
              ) : blocos.map((b, i) => {
                const excede = carrossel && b.conteudo.length > LIMITE_SLIDE;
                return (
                  <div key={i} className="cartao mb-3 overflow-hidden">
                    <div className="flex items-center gap-2.5 px-4 py-2.5 bg-[#FBFAF9] border-b border-linha">
                      <span className="font-titulo text-xs font-bold text-fgx-orange tracking-wide uppercase">
                        {carrossel ? `Slide ${i + 1} de ${blocos.length}` : `Trecho ${i + 1}`}
                      </span>
                      <span className={`text-[11.5px] ${excede ? "text-fgx-red font-bold" : "text-ink-3"}`}>{b.conteudo.length} car.</span>
                      <div className="ml-auto flex gap-1">
                        <Icone onClick={() => setBlocos(mover(blocos, i, i - 1))} disabled={i === 0} titulo="Subir">↑</Icone>
                        <Icone onClick={() => setBlocos(mover(blocos, i, i + 1))} disabled={i === blocos.length - 1} titulo="Descer">↓</Icone>
                        <Icone onClick={() => setBlocos(juntarComAnterior(blocos, i))} disabled={i === 0} titulo="Juntar com o anterior">⇡</Icone>
                        <Icone onClick={() => setBlocos(separarBloco(blocos, i))} titulo="Separar nas quebras de linha">⇵</Icone>
                        <Icone onClick={() => { if (b.conteudo.length < 40 || confirm("Remover este bloco?")) setBlocos(blocos.filter((_, k) => k !== i)); }} titulo="Remover">✕</Icone>
                      </div>
                    </div>
                    <div className="px-4 py-3">
                      {!carrossel && (
                        <input className="w-full border-0 outline-none font-titulo font-bold text-[15.5px] mb-2"
                          placeholder="Título do trecho (opcional)" value={b.titulo}
                          onChange={(e) => setBlocos(blocos.map((x, k) => k === i ? { ...x, titulo: e.target.value } : x))} />
                      )}
                      <textarea className="w-full border-0 outline-none resize-y min-h-[80px] text-[14.5px] leading-relaxed"
                        value={b.conteudo}
                        onChange={(e) => setBlocos(blocos.map((x, k) => k === i ? { ...x, conteudo: e.target.value } : x))} />
                    </div>
                    {excede && (
                      <div className="text-[11.5px] text-[#8A6208] bg-fgx-gold/[.13] px-4 py-2 border-t border-linha">
                        Acima do padrão de {LIMITE_SLIDE} caracteres por slide. O texto não é cortado — é só um aviso.
                      </div>
                    )}
                  </div>
                );
              })}
            </>
          )}

          {aba === "gancho" && (
            <div className="cartao p-5">
              <h3 className="text-[18px] font-bold mb-1.5">Gancho e ancoragem</h3>
              <p className="text-[13px] text-ink-3 mb-5">
                O fato, norma ou movimento que sustenta a peça. É o que separa conteúdo ancorado de opinião solta.
              </p>
              <div className="mb-4">
                <label className="rotulo">Qual é o gancho</label>
                <textarea className="campo min-h-[90px]" value={r.gancho_texto}
                  onChange={(e) => setR({ ...r, gancho_texto: e.target.value })} />
                <p className="text-xs text-ink-3 mt-1.5">Escreva o fato, não o tema. Sem fato externo, a peça é analítica.</p>
              </div>
              <label className="rotulo">Classificação da ancoragem</label>
              {(["jornalistico", "analitico"] as const).map((t) => (
                <label key={t} onClick={() => setR({ ...r, gancho_tipo: t })}
                  className={`flex gap-3 items-start px-4 py-3.5 border-[1.5px] rounded-xl cursor-pointer mb-2.5 transition
                    ${r.gancho_tipo === t ? "border-fgx-red bg-fgx-red/[.04]" : "border-linha hover:border-ink-3"}`}>
                  <input type="radio" checked={r.gancho_tipo === t} onChange={() => {}} className="mt-1 accent-fgx-red" />
                  <span>
                    <span className="font-semibold text-[14.5px] block">{t === "jornalistico" ? "Jornalístico" : "Analítico"}</span>
                    <span className="text-[12.5px] text-ink-3 leading-snug">
                      {t === "jornalistico"
                        ? "Ancorado em fato externo datado — norma publicada, decisão, movimento regulatório, evento."
                        : "Sem fato externo datado. A peça se sustenta na leitura própria do escritório."}
                    </span>
                  </span>
                </label>
              ))}
              <div className="grid grid-cols-2 max-lg:grid-cols-1 gap-4 mt-4">
                <Campo rotulo="Link da ancoragem">
                  <input className="campo" placeholder="https://" value={r.gancho_url}
                    onChange={(e) => setR({ ...r, gancho_url: e.target.value })} />
                </Campo>
                <Campo rotulo="Data do fato">
                  <input className="campo" type="date" value={r.gancho_data ?? ""}
                    onChange={(e) => setR({ ...r, gancho_data: e.target.value || null })} />
                </Campo>
              </div>
              {r.gancho_tipo === "jornalistico" && !r.gancho_url && (
                <div className="text-[11.5px] text-[#8A6208] bg-fgx-gold/[.13] px-4 py-3 rounded-lg mt-4 leading-snug">
                  Ancoragem jornalística sem link registrado. A trava da Síntese pede fato verificável — e caso
                  ativo de cliente não pode ser ancoragem sem autorização expressa.
                </div>
              )}
            </div>
          )}

          {aba === "trilha" && (
            <ListaEditavel
              titulo="Trilha de produção"
              descricao="As etapas que geraram a peça, na ordem. O cliente vê como linha do tempo."
              itens={trilha} setItens={setTrilha}
              vazio={{ passo: "", descricao: "" }}
              acaoExtra={{ rotulo: "Carregar as 9 etapas padrão", onClick: () => {
                if (trilha.length && !confirm("Isso substitui as etapas atuais. Continuar?")) return;
                setTrilha(TRILHA_PADRAO.map((t) => ({ ...t })));
              } }}
              campos={[{ chave: "passo", tipo: "titulo", placeholder: "Nome da etapa" },
                       { chave: "descricao", tipo: "texto", placeholder: "O que foi feito nesta etapa" }]}
              rotuloItem={(i) => `Etapa ${i + 1}`} />
          )}

          {aba === "raciocinios" && (
            <ListaEditavel
              titulo="Raciocínios da produção"
              descricao="Por que este ângulo, que tensão de marca trabalha, o que foi descartado."
              itens={raciocinios} setItens={setRaciocinios}
              vazio={{ titulo: "", texto: "" }}
              acaoExtra={{ rotulo: "Usar os 3 títulos padrão", onClick: () => {
                const padrao = ["Por que este ângulo", "Que tensão de marca trabalha", "O que foi descartado"];
                setRaciocinios([...raciocinios, ...padrao
                  .filter((t) => !raciocinios.some((r2) => r2.titulo === t))
                  .map((titulo) => ({ titulo, texto: "" }))]);
              } }}
              campos={[{ chave: "titulo", tipo: "titulo", placeholder: "Título do raciocínio" },
                       { chave: "texto", tipo: "texto", placeholder: "A explicação, do jeito que o cliente vai ler" }]}
              rotuloItem={(i) => `Raciocínio ${i + 1}`} />
          )}

          {aba === "fontes" && (
            <>
              <div className="cartao p-5 mb-4 flex items-center gap-3 flex-wrap">
                <div className="flex-1 min-w-[240px]">
                  <h3 className="text-[18px] font-bold mb-1">Fontes consultadas</h3>
                  <p className="text-[13px] text-ink-3">A Síntese pede de 3 a 5 fontes por peça.</p>
                </div>
                <button className="btn-escuro btn-p" onClick={() => setFontes([...fontes, { titulo: "", url: "", tipo: "Legislação", data_publicacao: null }])}>+ Fonte</button>
              </div>
              {fontes.length > 0 && fontes.length < 3 && (
                <div className="text-[11.5px] text-[#8A6208] bg-fgx-gold/[.13] px-4 py-2.5 rounded-lg mb-3">
                  {fontes.length} de 3 a 5 fontes previstas na Síntese.
                </div>
              )}
              {fontes.map((f, i) => (
                <div key={i} className="cartao p-5 mb-3">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="font-titulo text-xs font-bold text-fgx-orange uppercase tracking-wide">Fonte {i + 1}</span>
                    <div className="ml-auto flex gap-1">
                      <Icone onClick={() => setFontes(mover(fontes, i, i - 1))} disabled={i === 0} titulo="Subir">↑</Icone>
                      <Icone onClick={() => setFontes(mover(fontes, i, i + 1))} disabled={i === fontes.length - 1} titulo="Descer">↓</Icone>
                      <Icone onClick={() => setFontes(fontes.filter((_, k) => k !== i))} titulo="Remover">✕</Icone>
                    </div>
                  </div>
                  <Campo rotulo="Título">
                    <input className="campo" value={f.titulo}
                      onChange={(e) => setFontes(fontes.map((x, k) => k === i ? { ...x, titulo: e.target.value } : x))} />
                  </Campo>
                  <Campo rotulo="Link">
                    <input className="campo" placeholder="https://" value={f.url}
                      onChange={(e) => setFontes(fontes.map((x, k) => k === i ? { ...x, url: e.target.value } : x))} />
                  </Campo>
                  <div className="grid grid-cols-2 max-lg:grid-cols-1 gap-4">
                    <Campo rotulo="Tipo">
                      <select className="campo" value={f.tipo}
                        onChange={(e) => setFontes(fontes.map((x, k) => k === i ? { ...x, tipo: e.target.value } : x))}>
                        {TIPOS_FONTE.map((t) => <option key={t}>{t}</option>)}
                      </select>
                    </Campo>
                    <Campo rotulo="Data (opcional)">
                      <input className="campo" type="date" value={f.data_publicacao ?? ""}
                        onChange={(e) => setFontes(fontes.map((x, k) => k === i ? { ...x, data_publicacao: e.target.value || null } : x))} />
                    </Campo>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>

        <aside className="sticky top-[88px] max-xl:static">
          <div className="cartao p-5 mb-3.5">
            <h4 className="text-[15px] font-bold mb-3">Resumo da peça</h4>
            <Linha rotulo="Blocos" valor={String(blocos.length)} />
            <Linha rotulo="Caracteres" valor={numeroBr(total)} />
            {limiteCanal && <Linha rotulo="Limite do canal" valor={total > limiteCanal ? "acima" : "ok"} ruim={total > limiteCanal} />}
            {carrossel && <Linha rotulo={`Slides acima de ${LIMITE_SLIDE}`} valor={String(acimaDoSlide)} ruim={acimaDoSlide > 0} />}
          </div>
          <div className="cartao p-5 mb-3.5">
            <h4 className="text-[15px] font-bold mb-1">Camadas de processo</h4>
            <p className="text-[12.5px] text-ink-3 mb-3">É o que demonstra robustez ao cliente na página da peça.</p>
            <Linha rotulo="Gancho registrado" valor={r.gancho_texto ? "sim" : "não"} ruim={!r.gancho_texto} />
            <Linha rotulo="Trilha" valor={`${trilha.length} etapas`} ruim={!trilha.length} />
            <Linha rotulo="Raciocínios" valor={String(raciocinios.length)} ruim={!raciocinios.length} />
            <Linha rotulo="Fontes" valor={String(fontes.length)} ruim={fontes.length < 3} />
          </div>
          <div className="cartao p-5">
            <button className="btn-primario btn-p w-full" onClick={salvar} disabled={salvando}>Salvar peça</button>
          </div>
        </aside>
      </div>
    </>
  );
}

function Campo({ rotulo, children }: { rotulo: string; children: React.ReactNode }) {
  return <div className="mb-4"><label className="rotulo">{rotulo}</label>{children}</div>;
}

function Linha({ rotulo, valor, ruim }: { rotulo: string; valor: string; ruim?: boolean }) {
  return (
    <div className="flex justify-between py-2 border-b border-linha last:border-0 text-[13.5px]">
      <span>{rotulo}</span>
      <b className={`font-titulo text-[15px] ${ruim === undefined ? "" : ruim ? "text-fgx-red" : "text-fgx-green"}`}>{valor}</b>
    </div>
  );
}

function Icone({ children, onClick, disabled, titulo }:
  { children: React.ReactNode; onClick: () => void; disabled?: boolean; titulo: string }) {
  return (
    <button onClick={onClick} disabled={disabled} title={titulo} aria-label={titulo}
      className="w-7 h-7 rounded-md grid place-items-center text-ink-3 hover:bg-black/5 hover:text-ink disabled:opacity-25">
      {children}
    </button>
  );
}

/** Lista genérica com título + texto por item, usada por trilha e raciocínios. */
function ListaEditavel<T extends Record<string, string>>(
  { titulo, descricao, itens, setItens, vazio, campos, rotuloItem, acaoExtra }:
  { titulo: string; descricao: string; itens: T[]; setItens: (v: T[]) => void; vazio: T;
    campos: { chave: keyof T; tipo: "titulo" | "texto"; placeholder: string }[];
    rotuloItem: (i: number) => string; acaoExtra?: { rotulo: string; onClick: () => void } },
) {
  return (
    <>
      <div className="cartao p-5 mb-4 flex items-center gap-3 flex-wrap">
        <div className="flex-1 min-w-[240px]">
          <h3 className="text-[18px] font-bold mb-1">{titulo}</h3>
          <p className="text-[13px] text-ink-3">{descricao}</p>
        </div>
        {acaoExtra && <button className="btn-contorno btn-p" onClick={acaoExtra.onClick}>{acaoExtra.rotulo}</button>}
        <button className="btn-escuro btn-p" onClick={() => setItens([...itens, { ...vazio }])}>+ Item</button>
      </div>
      {itens.length === 0 && <div className="cartao p-10 text-center text-ink-3 text-sm">Nada registrado ainda.</div>}
      {itens.map((item, i) => (
        <div key={i} className="cartao mb-3 overflow-hidden">
          <div className="flex items-center gap-2.5 px-4 py-2.5 bg-[#FBFAF9] border-b border-linha">
            <span className="font-titulo text-xs font-bold text-fgx-orange uppercase tracking-wide">{rotuloItem(i)}</span>
            <div className="ml-auto flex gap-1">
              <Icone onClick={() => setItens(mover(itens, i, i - 1))} disabled={i === 0} titulo="Subir">↑</Icone>
              <Icone onClick={() => setItens(mover(itens, i, i + 1))} disabled={i === itens.length - 1} titulo="Descer">↓</Icone>
              <Icone onClick={() => setItens(itens.filter((_, k) => k !== i))} titulo="Remover">✕</Icone>
            </div>
          </div>
          <div className="px-4 py-3">
            {campos.map((c) => c.tipo === "titulo" ? (
              <input key={String(c.chave)} className="w-full border-0 outline-none font-titulo font-bold text-[15.5px] mb-2"
                placeholder={c.placeholder} value={item[c.chave]}
                onChange={(e) => setItens(itens.map((x, k) => k === i ? { ...x, [c.chave]: e.target.value } : x))} />
            ) : (
              <textarea key={String(c.chave)} className="w-full border-0 outline-none resize-y min-h-[70px] text-[14.5px] leading-relaxed"
                placeholder={c.placeholder} value={item[c.chave]}
                onChange={(e) => setItens(itens.map((x, k) => k === i ? { ...x, [c.chave]: e.target.value } : x))} />
            ))}
          </div>
        </div>
      ))}
    </>
  );
}
