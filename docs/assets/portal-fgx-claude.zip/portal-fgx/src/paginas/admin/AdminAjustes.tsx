import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { aditivos, ajustes, baixarJson, baixarTexto, clientes, enviarParaAvaliacao, marcarAjusteAplicado } from "../../lib/apiAdmin";
import { dataBr } from "../../lib/formato";
import { Aviso, Carregando, Vazio } from "../../componentes/Basicos";
import type { Ajuste, Cliente } from "../../lib/tipos";

export default function AdminAjustes() {
  const [lista, setLista] = useState<Cliente[]>([]);
  const [clienteId, setClienteId] = useState("");
  const [itens, setItens] = useState<(Ajuste & { peca: { tema: string } })[]>([]);
  const [docs, setDocs] = useState<any[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [aviso, setAviso] = useState<{ texto: string; tipo: "ok" | "erro" } | null>(null);

  async function carregar() {
    setItens(await ajustes());
    if (clienteId) setDocs(await aditivos(clienteId));
  }
  useEffect(() => { (async () => {
    const c = await clientes(); setLista(c); setClienteId(c[0]?.id ?? "");
    await carregar(); setCarregando(false);
  })(); /* eslint-disable-next-line */ }, []);
  useEffect(() => { if (clienteId) aditivos(clienteId).then(setDocs); }, [clienteId]);

  async function enviar(a: Ajuste) {
    try {
      const r = await enviarParaAvaliacao(a.id);
      if (r.modo === "download") {
        baixarJson(`ajuste-${a.id}.json`, r.pacote);
        setAviso({ texto: "Sem webhook configurado — o JSON foi baixado para levar à ferramenta de IA", tipo: "ok" });
      } else {
        setAviso({ texto: `Enviado para avaliação: ${r.resultado}`, tipo: "ok" });
      }
      await carregar();
    } catch (e) { setAviso({ texto: (e as Error).message, tipo: "erro" }); }
  }

  if (carregando) return <Carregando o="os ajustes" />;

  return (
    <>
      {aviso && <Aviso texto={aviso.texto} tipo={aviso.tipo} aoFechar={() => setAviso(null)} />}
      <div className="flex items-start gap-4 mb-7 flex-wrap">
        <div>
          <h1 className="text-[29px] font-bold tracking-tight">Ajustes e documentos aditivos</h1>
          <p className="text-sm text-ink-3 mt-1.5 max-w-[620px]">
            Os ajustes registrados a partir dos comentários, e os aditivos gerados pelos que mudam a regra-base do cliente.
          </p>
        </div>
        <div className="ml-auto">
          <label className="rotulo">Cliente</label>
          <select className="campo py-2" value={clienteId} onChange={(e) => setClienteId(e.target.value)}>
            {lista.map((c) => <option key={c.id} value={c.id}>{c.nome}</option>)}
          </select>
        </div>
      </div>

      <h3 className="text-[18px] font-bold mb-3">Ajustes registrados ({itens.length})</h3>
      {itens.length === 0 ? <Vazio>Nenhum ajuste registrado ainda.</Vazio> : itens.map((a) => (
        <div key={a.id} className="cartao p-5 mb-3">
          <div className="flex gap-2 items-center mb-2.5 flex-wrap">
            <span className={a.tipo === "estrutural" ? "etiqueta bg-fgx-red/10 text-fgx-red" : "etiqueta-n"}>
              {a.tipo === "estrutural" ? "Estrutural" : "Pontual"}
            </span>
            <span className="etiqueta-n capitalize">{a.status_avaliacao}</span>
            <span className="ml-auto text-xs text-ink-3">{a.peca?.tema}</span>
          </div>
          <div className="text-[13.5px] leading-relaxed">{a.descricao}</div>
          {a.enviado_em && (
            <div className="text-xs text-ink-3 italic mt-2">
              Enviado para avaliação em {dataBr(a.enviado_em)} · {a.enviado_resultado}
            </div>
          )}
          <div className="flex gap-2 mt-3 pt-3 border-t border-linha flex-wrap">
            {a.status_avaliacao !== "aplicado" && (
              <button className="btn-verde btn-p" onClick={async () => { await marcarAjusteAplicado(a.id); await carregar(); }}>
                Marcar como aplicado
              </button>
            )}
            <button className="btn-contorno btn-p" onClick={() => enviar(a)}>Enviar para avaliação</button>
            <Link className="btn-contorno btn-p" to={`/admin/pecas/${a.peca_id}`}>Abrir a peça</Link>
          </div>
        </div>
      ))}

      <h3 className="text-[18px] font-bold mt-8 mb-3">Documentos aditivos ({docs.length})</h3>
      {docs.length === 0 ? (
        <Vazio>Nenhum aditivo ainda.<br />Eles são gerados quando um ajuste é classificado como <b>estrutural</b>.</Vazio>
      ) : docs.map((d) => (
        <div key={d.id} className="cartao p-5 mb-3">
          <div className="font-semibold text-[13.5px] mb-2">{d.titulo}</div>
          <div className="text-xs text-ink-3 mb-3">{dataBr(d.criado_em)}</div>
          <button className="btn-escuro btn-p" onClick={() => baixarTexto("aditivo.md", d.conteudo)}>Exportar .md</button>
        </div>
      ))}
    </>
  );
}
