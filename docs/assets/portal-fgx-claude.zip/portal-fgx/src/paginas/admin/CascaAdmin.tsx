import { Navigate, Outlet, useLocation } from "react-router-dom";
import { Layout, type ItemNav } from "../../componentes/Layout";
import { lerSessao } from "../../lib/sessao";

const ic = (d: string) => (
  <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="1.85" strokeLinecap="round" strokeLinejoin="round" dangerouslySetInnerHTML={{ __html: d }} />
);

export default function CascaAdmin() {
  const sessao = lerSessao();
  const local = useLocation();
  if (!sessao?.is_admin) return <Navigate to="/admin" replace />;

  const itens: ItemNav[] = [
    { para: "/admin/ciclos", nome: "Ciclos e peças", icone: ic('<rect x="4" y="5" width="16" height="16" rx="2"/><path d="M8 3v4M16 3v4M4 11h16"/>') },
    { para: "/admin/comentarios", nome: "Comentários", icone: ic('<path d="M21 12a8 8 0 01-8 8H7l-4 3V12a8 8 0 018-8h2a8 8 0 018 8z"/>') },
    { para: "/admin/ajustes", nome: "Ajustes e aditivos", icone: ic('<path d="M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/>') },
    { para: "/admin/entregaveis", nome: "Entregáveis", icone: ic('<path d="M4 7a2 2 0 012-2h4l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H6a2 2 0 01-2-2z"/>') },
    { para: "/admin/clientes", nome: "Clientes e canais", icone: ic('<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0112 0"/>') },
  ];
  const atual = itens.find((i) => local.pathname.startsWith(i.para));

  return (
    <Layout variante="admin" itens={itens} titulo="Portal FGX" subtitulo="Painel interno"
      trilha={<><span>FGX</span><span>/</span><b className="text-ink font-semibold">{atual?.nome ?? "Peça"}</b></>}>
      {sessao.senha_inicial_trocada === false && (
        <div className="bg-fgx-gold/20 text-[#7A5405] text-[12.5px] px-4 py-3 rounded-xl mb-6 leading-snug">
          <b>Senha inicial de administrador ainda não foi trocada.</b> Enquanto isso não acontecer, este aviso
          continua em todas as telas. Troque em Configurações.
        </div>
      )}
      <Outlet />
    </Layout>
  );
}
