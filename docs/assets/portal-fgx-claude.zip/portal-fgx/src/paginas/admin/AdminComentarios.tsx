import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  ciclosDoCliente, clientes, comentariosDoCiclo, marcarTratado,
  montarAditivo, registrarAjuste, salvarAditivo, baixarTexto,
} from "../../lib/apiAdmin";
import { dataHoraBr, mesBr } from "../../lib/formato";
import { Aviso, Carregando, Vazio } from "../../componentes/Basicos";
import type { Cliente, TipoAjuste } from "../../lib/tipos";

type Item = Awaited<ReturnType<typeof comentariosDoCiclo>>[number];

export default function AdminComentarios() {
  const [lista, setLista] = useState<Cliente[]>([]);
  const [clienteId, setClienteId] = useState("");
  const [cicloId, setCicloId] = useState("");
  const [ciclosLista, setCiclosLista] = useState<{ id: string; mes_referencia: string }[]>([]);
  const [itens, setItens] = useState<Item[]>([]);
  const [filtro, setFiltro] = useState<"pendentes" | "tratados" | "todos">("pendentes");
  const [carregando, setCarregando] = useState(true);
  const [aviso, setAviso] = useState<{ texto: string; tipo: "ok" | "erro" } | null>(null);
  const [modal, setModal] = useState<Item | null>(null);
  const [descricao, setDescricao] = useState("");
  const [tipo, setTipo] = useState<TipoAjuste>("pontual");

  useEffect(() => { (async () => {
    const c = await clientes(); setLista(c); setClienteId(c[0]?.id ?? ""); setCarregando(false);
  })(); }, []);

  useEffect(() => { if (!clienteId) return; (async () => {
    const cs = await ciclosDoCliente(clienteId);
    setCiclosLista(cs); setCicloId(cs[0]?.id ?? "");
  })(); }, [clienteId]);

  async function recarregar() {
    if (!cicloId) { setItens([]); return; }
    setItens(await comentariosDoCiclo(cicloId));
  }
  useEffect(() => { recarregar(); /* eslint-disable-next-line */ }, [cicloId]);

  const visiveis = itens.filter((i) =>
    filtro === "todos" ? true : filtro === "pendentes" ? !i.tratado : i.tratado);

  async function alternarTratado(i: Item) {
    await marcarTratado(i.id, !i.tratado);
    await recarregar();
    setAviso({ texto: i.tratado ? "Reaberto" : "Marcado como tratado", tipo: "ok" });
  }

  async function confirmarAjuste() {
    if (!modal) return;
    if (descricao.trim().length < 10) return setAviso({ texto: "Descreva o ajuste antes de registrar.", tipo: "erro" });
    try {
      const ajuste = await registrarAjuste(modal.peca.id, modal.id, descricao.trim(), tipo);
      if (tipo === "estrutural") {
        const cliente = lista.find((c) => c.id === clienteId)!;
        const md = montarAditivo(cliente.nome, modal.peca.tema, descricao.trim());
        const titulo = `Aditivo — ${descricao.trim().slice(0, 52)}…`;
        await salvarAditivo(clienteId, ajuste.id, titulo, md);
        baixarTexto("aditivo.md", md);
        setAviso({ texto: "Ajuste estrutural registrado e documento aditivo gerado", tipo: "ok" });
      } else {
        setAviso({ texto: "Ajuste pontual registrado", tipo: "ok" });
      }
      setModal(null); setDescricao(""); setTipo("pontual");
      await recarregar();
    } catch (e) { setAviso({ texto: (e as Error).message, tipo: "erro" }); }
  }

  if (carregando) return <Carregando o="os comentários" />;
  const pendentes = itens.filter((i) => !i.tratado).length;

  return (
    <>
      {aviso && <Aviso texto={aviso.texto} tipo={aviso.tipo} aoFechar={() => setAviso(null)} />}

      <div className="flex items-start gap-4 mb-7 flex-wrap">
        <div>
          <h1 className="text-[29px] font-bold tracking-tight">Comentários do cliente</h1>
          <p className="text-sm text-ink-3 mt-1.5 max-w-[620px]">
            Tudo o que o escritório escreveu no ciclo, em um lugar só. Cada comentário vira — ou não — um ajuste registrado.
          </p>
        </div>
        <div className="ml-auto flex gap-2.5 items-end flex-wrap">
          <div>
            <label className="rotulo">Cliente</label>
            <select className="campo py-2" value={clienteId} onChange={(e) => setClienteId(e.target.value)}>
              {lista.map((c) => <option key={c.id} value={c.id}>{c.nome}</option>)}
            </select>
          </div>
          {ciclosLista.length > 0 && (
            <div>
              <label className="rotulo">Ciclo</label>
              <select className="campo py-2" value={cicloId} onChange={(e) => setCicloId(e.target.value)}>
                {ciclosLista.map((c) => <option key={c.id} value={c.id}>{mesBr(c.mes_referencia)}</option>)}
              </select>
            </div>
          )}
        </div>
      </div>

      <div className="flex bg-fundo rounded-xl p-1 w-fit gap-0.5 mb-5">
        {([["pendentes", `A tratar (${pendentes})`], ["tratados", `Tratados (${itens.length - pendentes})`], ["todos", `Todos (${itens.length})`]] as const).map(([k, r]) => (
          <button key={k} onClick={() => setFiltro(k)}
            className={`px-3.5 py-2 rounded-lg text-[12.5px] font-semibold ${filtro === k ? "bg-white text-fgx-red shadow-sm" : "text-ink-3"}`}>{r}</button>
        ))}
      </div>

      <div className="grid grid-cols-[1fr_380px] max-xl:grid-cols-1 gap-5 items-start">
        <div>
          {visiveis.length === 0 ? <Vazio>Nenhum comentário nesta lista.</Vazio> : visiveis.map((i) => (
            <div key={i.id} className={`cartao p-5 mb-3 ${i.tratado ? "opacity-60" : ""}`}>
              <div className="flex items-center gap-2 flex-wrap mb-2.5 text-xs text-ink-3">
                <b className="text-ink text-[13.5px]">{i.autor_nome}</b><span>·</span><span>{dataHoraBr(i.criado_em)}</span>
                <span className="etiqueta-n">
                  {i.bloco ? (i.peca.formato === "carrossel" ? `Slide ${i.bloco.ordem}` : `Trecho ${i.bloco.ordem}`) : "Peça inteira"}
                </span>
                {i.tratado && <span className="ml-auto text-fgx-green font-semibold text-[11.5px]">✓ tratado</span>}
              </div>
              <div className="text-xs text-ink-3 bg-fundo rounded-lg px-3 py-2 mb-2.5 leading-snug">
                <b className="text-ink-2">{i.peca.tema}</b>
                {i.bloco && <><br />“{i.bloco.conteudo.slice(0, 110).replace(/\n/g, " ")}…”</>}
              </div>
              <div className="text-[14.5px] leading-relaxed border-l-[3px] border-fgx-blue pl-3.5 mb-3">{i.texto}</div>
              <div className="flex gap-2 flex-wrap border-t border-linha pt-3">
                <button className="btn-primario btn-p" onClick={() => { setModal(i); setDescricao(""); setTipo("pontual"); }}>
                  Registrar ajuste
                </button>
                <Link className="btn-contorno btn-p" to={`/admin/pecas/${i.peca.id}`}>Abrir a peça</Link>
                <button className="btn-contorno btn-p" onClick={() => alternarTratado(i)}>
                  {i.tratado ? "Reabrir" : "Marcar como tratado sem ajuste"}
                </button>
              </div>
            </div>
          ))}
        </div>

        <aside className="cartao p-5 sticky top-[88px] max-xl:static">
          <h4 className="text-[15px] font-bold mb-3">Como isso funciona</h4>
          <p className="text-[13.5px] text-ink-2 leading-relaxed mb-3.5">
            Todo comentário do cliente termina em uma de três saídas — e nenhuma delas é ficar parado.
          </p>
          {[["Ajuste pontual", "muda só aquela peça"],
            ["Ajuste estrutural", "muda a regra-base do cliente e gera documento aditivo"],
            ["Tratado sem ajuste", "elogio, confirmação ou observação que não pede mudança"]].map(([t, d]) => (
            <div key={t} className="py-2 border-b border-linha last:border-0">
              <b className="text-[13.5px]">{t}</b>
              <div className="text-xs text-ink-3">{d}</div>
            </div>
          ))}
        </aside>
      </div>

      {modal && (
        <div className="fixed inset-0 bg-black/55 z-50 grid place-items-center p-6" onClick={(e) => e.target === e.currentTarget && setModal(null)}>
          <div className="bg-white rounded-2xl w-full max-w-[620px] max-h-[88vh] flex flex-col shadow-2xl">
            <div className="px-6 py-5 border-b border-linha"><h3 className="text-[19px] font-bold">Registrar ajuste</h3></div>
            <div className="px-6 py-5 overflow-y-auto">
              <div className="text-xs text-ink-3 bg-fundo rounded-lg px-3 py-2 mb-4">
                <b className="text-ink-2">{modal.peca.tema}</b><br />{modal.autor_nome} · {dataHoraBr(modal.criado_em)}
              </div>
              <div className="text-[14.5px] leading-relaxed border-l-[3px] border-fgx-blue pl-3.5 mb-5">{modal.texto}</div>
              <div className="mb-4">
                <label className="rotulo">Descrição do ajuste</label>
                <textarea className="campo min-h-[90px]" value={descricao} onChange={(e) => setDescricao(e.target.value)}
                  placeholder="O que exatamente será mudado" />
                <p className="text-xs text-ink-3 mt-1.5">Escreva a mudança, não o problema. É este texto que o cliente vê na peça.</p>
              </div>
              <label className="rotulo">Classificação</label>
              {(["pontual", "estrutural"] as TipoAjuste[]).map((t) => (
                <label key={t} onClick={() => setTipo(t)}
                  className={`flex gap-3 items-start px-4 py-3.5 border-[1.5px] rounded-xl cursor-pointer mb-2.5 transition
                    ${tipo === t ? "border-fgx-red bg-fgx-red/[.04]" : "border-linha hover:border-ink-3"}`}>
                  <input type="radio" checked={tipo === t} onChange={() => {}} className="mt-1 accent-fgx-red" />
                  <span>
                    <span className="font-semibold text-[14.5px] block capitalize">{t}</span>
                    <span className="text-[12.5px] text-ink-3 leading-snug">
                      {t === "pontual"
                        ? "Muda só esta peça. Não altera a regra-base do cliente."
                        : "Muda a regra-base e vale para as próximas peças. Gera documento aditivo para a base de conhecimento."}
                    </span>
                  </span>
                </label>
              ))}
            </div>
            <div className="px-6 py-4 border-t border-linha flex gap-2.5 justify-end bg-[#FBFAF9] rounded-b-2xl">
              <button className="btn-contorno" onClick={() => setModal(null)}>Cancelar</button>
              <button className="btn-primario" onClick={confirmarAjuste}>Registrar ajuste</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
