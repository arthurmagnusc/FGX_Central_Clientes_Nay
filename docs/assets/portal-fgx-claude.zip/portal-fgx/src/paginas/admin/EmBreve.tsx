/**
 * Telas de cadastro direto que ficaram fora do protótipo validado.
 * O modelo de dados já suporta as duas; falta só a interface — e ela é
 * formulário simples, sem decisão de desenho pendente. Ver HANDOFF.md.
 */
export default function EmBreve({ nome }: { nome: string }) {
  return (
    <>
      <h1 className="text-[29px] font-bold tracking-tight mb-2">{nome}</h1>
      <p className="text-sm text-ink-3 max-w-[620px] mb-6">
        Esta tela está no escopo e o banco já a suporta, mas a interface não foi desenhada nesta rodada.
        Enquanto isso, o cadastro pode ser feito pelo painel do Supabase ou pelos scripts em <code>scripts/</code>.
      </p>
      <div className="cartao p-10 text-center text-ink-3 text-sm">Interface pendente.</div>
    </>
  );
}
