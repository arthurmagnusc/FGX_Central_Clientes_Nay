import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";

import Entrar from "./paginas/cliente/Entrar";
import CascaCliente from "./paginas/cliente/CascaCliente";
import VisaoGeral from "./paginas/cliente/VisaoGeral";
import Entregas from "./paginas/cliente/Entregas";
import Relatorios from "./paginas/cliente/Relatorios";
import PainelConteudos from "./paginas/cliente/PainelConteudos";
import PaginaPeca from "./paginas/cliente/PaginaPeca";

import EntrarAdmin from "./paginas/admin/EntrarAdmin";
import CascaAdmin from "./paginas/admin/CascaAdmin";
import AdminCiclos from "./paginas/admin/AdminCiclos";
import AdminPeca from "./paginas/admin/AdminPeca";
import AdminComentarios from "./paginas/admin/AdminComentarios";
import AdminAjustes from "./paginas/admin/AdminAjustes";
import EmBreve from "./paginas/admin/EmBreve";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* portal do cliente */}
        <Route path="/c/:slug" element={<Entrar />} />
        <Route path="/c/:slug" element={<CascaCliente />}>
          <Route path="visao-geral" element={<VisaoGeral />} />
          <Route path="entregas" element={<Entregas />} />
          <Route path="relatorios" element={<Relatorios />} />
          <Route path="conteudos" element={<PainelConteudos />} />
          <Route path="conteudos/:pecaId" element={<PaginaPeca />} />
        </Route>

        {/* painel interno */}
        <Route path="/admin" element={<EntrarAdmin />} />
        <Route path="/admin" element={<CascaAdmin />}>
          <Route path="ciclos" element={<AdminCiclos />} />
          <Route path="pecas/:pecaId" element={<AdminPeca />} />
          <Route path="comentarios" element={<AdminComentarios />} />
          <Route path="ajustes" element={<AdminAjustes />} />
          <Route path="entregaveis" element={<EmBreve nome="Entregáveis" />} />
          <Route path="clientes" element={<EmBreve nome="Clientes e canais" />} />
        </Route>

        <Route path="*" element={<Navigate to="/admin" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
